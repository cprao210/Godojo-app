import { app, BrowserWindow, Tray, Menu, nativeImage, ipcMain, shell, systemPreferences, screen } from "electron"
import path from "path"
import fs from "fs"
import { autoUpdater } from "electron-updater"
// Load app-level config (Supabase, Google/Zoom OAuth client credentials, Firebase).
// In dev this reads the repo-root `.env`. In a packaged build it reads the `.env`
// shipped via `extraResources` (written by CI from GitHub Actions secrets — see
// release.yml). This must run unconditionally — previously gated to `!app.isPackaged`,
// which meant packaged builds NEVER loaded these values, no matter what the CI
// job's own environment contained.
//
// IMPORTANT: never put user BYOK provider keys (Gemini/Groq/Claude/OpenAI/Deepgram/
// etc.) in this file — those are supplied per-user via Settings > AI Providers and
// stored through CredentialsManager. This file is the same for every install.
const runtimeEnvPath = app.isPackaged
  ? path.join(process.resourcesPath, '.env')
  : path.join(app.getAppPath(), '.env');
require('dotenv').config({ path: runtimeEnvPath }); // no-ops safely if the file is missing

// Handle stdout/stderr errors at the process level to prevent EIO crashes
// This is critical for Electron apps that may have their terminal detached
process.stdout?.on?.('error', () => { });
process.stderr?.on?.('error', () => { });

// ---------------------------------------------------------------------------
// Deep link handling (team invites): godojo://invite?token=... and, once the
// domain association files are hosted, https://app.godojo.ai/invite?token=...
// The token itself is just an opaque lookup key — all real validation
// (expiry, email match, single-use) happens server-side in tenantsApi calls
// made from the renderer, so we never trust this value beyond parsing it.
// ---------------------------------------------------------------------------
const INVITE_PROTOCOL = 'godojo';
let pendingInviteToken: string | null = null;

function extractInviteToken(url: string): string | null {
  try {
    const parsed = new URL(url);
    // Supports both godojo://invite?token=xxx and
    // https://app.godojo.ai/invite?token=xxx
    return parsed.searchParams.get('token');
  } catch (e) {
    console.warn('[Main] Failed to parse deep link URL:', url, e);
    return null;
  }
}

/**
 * Relay an invite deep link to the renderer. If the main window doesn't
 * exist yet (cold start still booting), stash the token and it'll be
 * flushed once the window finishes loading (see 'did-finish-load' below).
 */
function handleInviteDeepLink(url: string) {
  const token = extractInviteToken(url);
  if (!token) {
    console.warn('[Main] Received deep link with no token:', url);
    return;
  }

  const appState = AppState.getInstance();
  const win = appState.getMainWindow();

  if (win && !win.isDestroyed()) {
    if (!appState.isVisible()) {
      appState.toggleMainWindow();
    }
    win.focus();
    win.webContents.send('invite-deep-link', { token });
  } else {
    pendingInviteToken = token;
  }
}

// macOS: fired for godojo:// (and, once configured, associated https://)
// links — including cold starts, as long as this listener is registered
// before app.whenReady() resolves, which it is here (module load time).
app.on('open-url', (event, url) => {
  event.preventDefault();
  handleInviteDeepLink(url);
});

process.on('uncaughtException', (err) => {
  logToFile('[CRITICAL] Uncaught Exception: ' + (err.stack || err.message || err));
});

process.on('unhandledRejection', (reason, promise) => {
  logToFile('[CRITICAL] Unhandled Rejection at: ' + promise + ' reason: ' + (reason instanceof Error ? reason.stack : reason));
});

// CQ-04 fix: do NOT call app.getPath() at module load time.
// app.getPath('documents') is not guaranteed to be available before app.whenReady().
// Use a lazy getter instead — the path is resolved on first logToFile() call.
let _logFile: string | null = null;
const getLogFile = (): string | null => {
  if (_logFile) return _logFile;
  try {
    _logFile = path.join(app.getPath('documents'), 'natively_debug.log');
    return _logFile;
  } catch {
    // app.ready not yet fired — return null, logToFile will skip silently
    return null;
  }
};

const originalLog = console.log;
const originalWarn = console.warn;
const originalError = console.error;

/** Maximum log file size before rotation (10 MB). */
const LOG_MAX_BYTES = 10 * 1024 * 1024;

function logToFile(msg: string) {
  try {
    const logFile = getLogFile();
    // If the app isn't ready yet (path not available), skip silently.
    if (!logFile) return;

    // P2-1: rotate the log file when it exceeds LOG_MAX_BYTES so that long-running
    // sessions (or meetings with dense transcripts) don't fill the user's disk.
    // The previous log is kept as .log.1 for one-generation rollover.
    try {
      const stat = fs.statSync(logFile);
      if (stat.size >= LOG_MAX_BYTES) {
        const rotated = logFile + '.1';
        if (fs.existsSync(rotated)) fs.unlinkSync(rotated);
        fs.renameSync(logFile, rotated);
      }
    } catch {
      // statSync throws if the file doesn't exist yet — that's fine
    }
    fs.appendFileSync(logFile, new Date().toISOString() + ' ' + msg + '\n');
  } catch (e) {
    // Ignore logging errors
  }
}

async function ensureMacMicrophoneAccess(context: string): Promise<boolean> {
  if (process.platform !== 'darwin') return true;

  try {
    const currentStatus = systemPreferences.getMediaAccessStatus('microphone');
    console.log(`[Main] macOS microphone permission before ${context}: ${currentStatus}`);

    if (currentStatus === 'granted') {
      return true;
    }

    const granted = await systemPreferences.askForMediaAccess('microphone');
    console.log(
      `[Main] macOS microphone permission request during ${context}: ${granted ? 'granted' : 'denied'}`
    );
    return granted;
  } catch (error) {
    console.error(`[Main] Failed to check macOS microphone permission during ${context}:`, error);
    return false;
  }
}

console.log = (...args: any[]) => {
  const msg = args.map(a => (a instanceof Error) ? a.stack || a.message : (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ');
  logToFile('[LOG] ' + msg);
  try {
    originalLog.apply(console, args);
  } catch { }
};

console.warn = (...args: any[]) => {
  const msg = args.map(a => (a instanceof Error) ? a.stack || a.message : (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ');
  logToFile('[WARN] ' + msg);
  try {
    originalWarn.apply(console, args);
  } catch { }
};

console.error = (...args: any[]) => {
  const msg = args.map(a => (a instanceof Error) ? a.stack || a.message : (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ');
  logToFile('[ERROR] ' + msg);
  try {
    originalError.apply(console, args);
  } catch { }
};

import { initializeIpcHandlers } from "./ipcHandlers"
import { WindowHelper, initRendererUrl } from "./WindowHelper"
import { SettingsWindowHelper } from "./SettingsWindowHelper"
import { ModelSelectorWindowHelper } from "./ModelSelectorWindowHelper"
import { CropperWindowHelper } from "./CropperWindowHelper"
import { ScreenshotHelper } from "./ScreenshotHelper"
import { KeybindManager } from "./services/KeybindManager"
import { ProcessingHelper } from "./ProcessingHelper"

import { IntelligenceManager } from "./IntelligenceManager"
import { SystemAudioCapture } from "./audio/SystemAudioCapture"
import { MicrophoneCapture } from "./audio/MicrophoneCapture"
import { loadNativeModule } from "./audio/nativeModuleLoader"
import { TranscriptEchoFilter, type AecTelemetry } from "./audio/TranscriptEchoFilter"
import type { SttWord } from "./audio/sttWordUtils"
import { GoogleSTT } from "./audio/GoogleSTT"
import { RestSTT } from "./audio/RestSTT"
import { DeepgramStreamingSTT } from "./audio/DeepgramStreamingSTT"
import { SonioxStreamingSTT } from "./audio/SonioxStreamingSTT"
import { ElevenLabsStreamingSTT } from "./audio/ElevenLabsStreamingSTT"
import { OpenAIStreamingSTT } from "./audio/OpenAIStreamingSTT"
import { ThemeManager } from "./ThemeManager"
import { RAGManager } from "./rag/RAGManager"
import { DatabaseManager } from "./db/DatabaseManager"
import { warmupIntentClassifier } from "./llm"
import { AudioDevices } from "./audio/AudioDevices";

/** Unified type for all STT providers with optional extended capabilities */
type STTProvider = (GoogleSTT | RestSTT | DeepgramStreamingSTT | SonioxStreamingSTT | ElevenLabsStreamingSTT | OpenAIStreamingSTT) & {
  finalize?: () => void;
  setAudioChannelCount?: (count: number) => void;
  notifySpeechEnded?: () => void;
};

type ScreenshotWindowMode = 'launcher' | 'overlay';
type ScreenshotCaptureKind = 'full' | 'selective';

interface ScreenshotCaptureSession {
  captureKind: ScreenshotCaptureKind;
  wasMainWindowVisible: boolean;
  windowMode: ScreenshotWindowMode;
  wasSettingsVisible: boolean;
  wasModelSelectorVisible: boolean;
  overlayBounds: Electron.Rectangle | null;
  overlayDisplayId: number | null;
  restoreWithoutFocus: boolean;
}

// Premium: Knowledge modules loaded conditionally
let KnowledgeOrchestratorClass: any = null;
let KnowledgeDatabaseManagerClass: any = null;
try {
  KnowledgeOrchestratorClass = require('./premium/knowledge/KnowledgeOrchestrator').KnowledgeOrchestrator;
  KnowledgeDatabaseManagerClass = require('./premium/knowledge/KnowledgeDatabaseManager').KnowledgeDatabaseManager;
} catch {
  console.log('[Main] Knowledge modules not available — profile intelligence disabled.');
}

import { CredentialsManager } from "./services/CredentialsManager"
import { SettingsManager } from "./services/SettingsManager"
import { setVerboseLoggingFlag } from "./verboseLog"
import { ReleaseNotesManager } from "./update/ReleaseNotesManager"
import { OllamaManager } from './services/OllamaManager'
import { LiveAnalysisData } from "../src/types";

export class AppState {
  private static instance: AppState | null = null

  private windowHelper: WindowHelper
  public settingsWindowHelper: SettingsWindowHelper
  public modelSelectorWindowHelper: ModelSelectorWindowHelper
  public cropperWindowHelper: CropperWindowHelper
  private screenshotHelper: ScreenshotHelper
  public processingHelper: ProcessingHelper

  private intelligenceManager: IntelligenceManager
  private themeManager: ThemeManager
  private ragManager: RAGManager | null = null
  private knowledgeOrchestrator: any = null
  private tray: Tray | null = null
  private updateAvailable: boolean = false
  private disguiseMode: 'terminal' | 'settings' | 'activity' | 'none' = 'none'
  private _currentLiveAnalysis: LiveAnalysisData | null = null;
  private _companyIntel: Record<string, any> | null = null;
  // When setCurrentLiveAnalysis is called after endMeeting has already run, we
  // need to know which meetingId to patch. This is set by endMeeting() and cleared
  // after the late-arriving result is saved.
  private _pendingLiveAnalysisMeetingId: string | null = null;
  private _liveAnalysisInFlight: boolean = false;
  private speakerNameMap: { user: string, client: string };

  // View management
  private view: "queue" | "solutions" = "queue"
  private isUndetectable: boolean = false

  private problemInfo: {
    problem_statement: string
    input_format: Record<string, any>
    output_format: Record<string, any>
    constraints: Array<Record<string, any>>
    test_cases: Array<Record<string, any>>
  } | null = null // Allow null

  private hasDebugged: boolean = false
  private isMeetingActive: boolean = false; // Guard for session state leaks
  private isMeetingPaused: boolean = false; // Pause guard — blocks audio and AI while paused
  private _isQuitting: boolean = false;
  private _verboseLogging: boolean = false;
  private _disguiseTimers: NodeJS.Timeout[] = []; // Track forceUpdate timeouts
  private _dockDebounceTimer: NodeJS.Timeout | null = null; // Debounce dock state changes
  private _dockReassertTimers: NodeJS.Timeout[] = []; // Re-assert dock-hidden state after show+focus
  private _ollamaBootstrapPromise: Promise<void> | null = null;
  private screenshotCaptureInProgress: boolean = false;


  // Processing events
  public readonly PROCESSING_EVENTS = {
    //global states
    UNAUTHORIZED: "procesing-unauthorized",
    NO_SCREENSHOTS: "processing-no-screenshots",

    //states for generating the initial solution
    INITIAL_START: "initial-start",
    PROBLEM_EXTRACTED: "problem-extracted",
    SOLUTION_SUCCESS: "solution-success",
    INITIAL_SOLUTION_ERROR: "solution-error",

    //states for processing the debugging
    DEBUG_START: "debug-start",
    DEBUG_SUCCESS: "debug-success",
    DEBUG_ERROR: "debug-error"
  } as const

  constructor() {
    // 1. Load boot-critical settings first (used by WindowHelpers)
    const settingsManager = SettingsManager.getInstance();
    this.isUndetectable = settingsManager.get('isUndetectable') ?? false;
    this.disguiseMode = settingsManager.get('disguiseMode') ?? 'none';
    this._verboseLogging = settingsManager.get('verboseLogging') ?? false;
    setVerboseLoggingFlag(this._verboseLogging);
    console.log(`[AppState] Initialized with isUndetectable=${this.isUndetectable}, disguiseMode=${this.disguiseMode}, verboseLogging=${this._verboseLogging}`);

    // 2. Initialize Helpers with loaded state
    this.windowHelper = new WindowHelper(this)
    this.settingsWindowHelper = new SettingsWindowHelper()
    this.modelSelectorWindowHelper = new ModelSelectorWindowHelper()
    this.cropperWindowHelper = new CropperWindowHelper()

    // 3. Initialize other helpers
    this.screenshotHelper = new ScreenshotHelper(this.view)
    this.processingHelper = new ProcessingHelper(this)

    this.windowHelper.setContentProtection(this.isUndetectable);
    this.settingsWindowHelper.setContentProtection(this.isUndetectable);
    this.modelSelectorWindowHelper.setContentProtection(this.isUndetectable);
    this.cropperWindowHelper.setContentProtection(this.isUndetectable);

    if (process.platform === 'win32' || process.platform === 'darwin') {
      this.cropperWindowHelper.preload();
    }

    // Initialize KeybindManager
    const keybindManager = KeybindManager.getInstance();
    keybindManager.setWindowHelper(this.windowHelper);
    keybindManager.setupIpcHandlers();
    keybindManager.onUpdate(() => {
      this.updateTrayMenu();
    });

    keybindManager.onShortcutTriggered(async (actionId) => {
      console.log(`[Main] Global shortcut triggered: ${actionId}`);
      try {
        if (actionId === 'general:toggle-visibility') {
          this.toggleMainWindow();
        } else if (actionId === 'general:toggle-mouse-passthrough') {
          // Adapted from public PR #113 — verify premium interaction
          this.toggleOverlayMousePassthrough();
        } else if (actionId === 'general:take-screenshot') {
          const screenshotPath = await this.takeScreenshot(false);
          const preview = await this.getImagePreview(screenshotPath);
          const mainWindow = this.getMainWindow();
          if (mainWindow) {
            mainWindow.webContents.send("screenshot-taken", {
              path: screenshotPath,
              preview
            });
          }
        } else if (actionId === 'general:selective-screenshot') {
          const screenshotPath = await this.takeSelectiveScreenshot(false);
          const preview = await this.getImagePreview(screenshotPath);
          const mainWindow = this.getMainWindow();
          if (mainWindow) {
            // preload.ts maps 'screenshot-attached' to onScreenshotAttached
            mainWindow.webContents.send("screenshot-attached", {
              path: screenshotPath,
              preview
            });
          }
        } else if (actionId === 'general:capture-and-process') {
          // Single-trigger: capture current screen then immediately request AI analysis
          const screenshotPath = await this.takeScreenshot(false);
          const preview = await this.getImagePreview(screenshotPath);
          // Ensure the window is visible so the user can see the response without stealing focus
          this.showMainWindow(true);
          // win.focus() can cause macOS to re-activate the app. Re-hide the dock
          // if we are in undetectable mode.
          if (process.platform === 'darwin' && this.isUndetectable) {
            app.dock.hide();
          }
          const mainWindow = this.getMainWindow();
          if (mainWindow) {
            mainWindow.webContents.send("capture-and-process", {
              path: screenshotPath,
              preview
            });
          }

          // --- STEALTH SHORTCUTS: no focus, no show, pure IPC dispatch ---

          // Chat actions — fire into the renderer without focusing the window
        } else if (
          actionId === 'chat:whatToAnswer' ||
          actionId === 'chat:clarify' ||
          actionId === 'chat:followUp' ||
          actionId === 'chat:answer' ||
          actionId === 'chat:codeHint' ||
          actionId === 'chat:brainstorm' ||
          actionId === 'chat:dynamicAction4' ||
          actionId === 'chat:scrollUp' ||
          actionId === 'chat:scrollDown'
        ) {
          const actionMap: Record<string, string> = {
            'chat:whatToAnswer': 'whatToAnswer',
            'chat:clarify': 'clarify',
            'chat:followUp': 'followUp',
            'chat:answer': 'answer',
            'chat:codeHint': 'codeHint',
            'chat:brainstorm': 'brainstorm',
            'chat:dynamicAction4': 'dynamicAction4',
            'chat:scrollUp': 'scrollUp',
            'chat:scrollDown': 'scrollDown',
          };
          const action = actionMap[actionId];
          // Send to all windows without focusing — stealth operation
          const allWindows = BrowserWindow.getAllWindows();
          allWindows.forEach(win => {
            if (!win.isDestroyed()) {
              win.webContents.send('global-shortcut', { action });
            }
          });

          // Window movement — move window position without focus change
        } else if (actionId === 'window:move-up') {
          this.windowHelper.moveWindowUp();
        } else if (actionId === 'window:move-down') {
          this.windowHelper.moveWindowDown();
        } else if (actionId === 'window:move-left') {
          this.windowHelper.moveWindowLeft();
        } else if (actionId === 'window:move-right') {
          this.windowHelper.moveWindowRight();

          // General actions that are now global (stealth)
        } else if (actionId === 'general:process-screenshots') {
          const allWindows = BrowserWindow.getAllWindows();
          allWindows.forEach(win => {
            if (!win.isDestroyed()) {
              win.webContents.send('global-shortcut', { action: 'processScreenshots' });
            }
          });
        } else if (actionId === 'general:reset-cancel') {
          const allWindows = BrowserWindow.getAllWindows();
          allWindows.forEach(win => {
            if (!win.isDestroyed()) {
              win.webContents.send('global-shortcut', { action: 'resetCancel' });
            }
          });
        }
      } catch (e: any) {
        if (e.message !== "Selection cancelled" && e.message !== "Screenshot capture already in progress") {
          console.error(`[Main] Error handling global shortcut ${actionId}:`, e);
        }
      }
    });

    // Inject WindowHelper into other helpers
    this.settingsWindowHelper.setWindowHelper(this.windowHelper);
    this.modelSelectorWindowHelper.setWindowHelper(this.windowHelper);




    // Initialize IntelligenceManager with LLMHelper
    this.intelligenceManager = new IntelligenceManager(this.processingHelper.getLLMHelper())

    // Initialize ThemeManager
    this.themeManager = ThemeManager.getInstance()

    // Initialize RAGManager (requires database to be ready)
    this.initializeRAGManager()

    // Check and prep Ollama embedding model
    this.bootstrapOllamaEmbeddings()


    this.setupIntelligenceEvents()

    // Pre-warm the zero-shot intent classifier in background
    warmupIntentClassifier();

    // Setup Ollama IPC
    this.setupOllamaIpcHandlers()

    // --- NEW SYSTEM AUDIO PIPELINE (SOX + NODE GOOGLE STT) ---
    // LAZY INIT: Do not setup pipeline here to prevent launch volume surge.
    // this.setupSystemAudioPipeline()

    // Initialize Auto-Updater
    this.setupAutoUpdater()
  }

  private broadcast(channel: string, ...args: any[]): void {
    BrowserWindow.getAllWindows().forEach(win => {
      if (!win.isDestroyed()) {
        win.webContents.send(channel, ...args);
      }
    });
  }

  public getIsMeetingActive(): boolean {
    return this.isMeetingActive;
  }

  public getIsMeetingPaused(): boolean {
    return this.isMeetingPaused;
  }

  public isQuitting(): boolean {
    return this._isQuitting;
  }

  public setQuitting(value: boolean): void {
    this._isQuitting = value;
  }

  public setCompanyIntel(intel: Record<string, any> | null): void {
    this._companyIntel = intel;
    console.log('[AppState] Company intel set:', intel?.companyName ?? 'cleared');
  }

  public getCompanyIntel(): Record<string, any> | null {
    return this._companyIntel;
  }

  private broadcastMeetingState(): void {
    this.broadcast('meeting-state-changed', { isActive: this.isMeetingActive });
  }

  private broadcastMeetingPauseState(): void {
    this.broadcast('meeting-pause-state-changed', { isPaused: this.isMeetingPaused });
  }

  private async bootstrapOllamaEmbeddings() {
    this._ollamaBootstrapPromise = (async () => {
      try {
        const { OllamaBootstrap } = require('./rag/OllamaBootstrap');
        const bootstrap = new OllamaBootstrap();

        // Fire and forget — don't await this before showing the window
        const result = await bootstrap.bootstrap('nomic-embed-text', (status: string, percent: number) => {
          // Send progress to renderer via IPC
          this.broadcast('ollama:pull-progress', { status, percent });
        });

        if (result === 'pulled' || result === 'already_pulled') {
          this.broadcast('ollama:pull-complete');
          // Re-resolve the embedding provider given that Ollama might now be available
          if (this.ragManager) {
            console.log('[AppState] Ollama model ready, re-evaluating RAG pipeline provider');
            const { CredentialsManager } = require('./services/CredentialsManager');
            const cm = CredentialsManager.getInstance();
            this.ragManager.initializeEmbeddings({
              openaiKey: cm.getOpenaiApiKey() || process.env.OPENAI_API_KEY || undefined,
              geminiKey: cm.getGeminiApiKey() || process.env.GOOGLE_API_KEY || undefined,
              ollamaUrl: process.env.OLLAMA_URL || "http://localhost:11434"
            });
          }
        }
      } catch (err) {
        console.error('[AppState] Failed to bootstrap Ollama:', err);
      }
    })();
  }

  private initializeRAGManager(): void {
    try {
      const db = DatabaseManager.getInstance();
      const sqliteDb = db.getDb();

      if (sqliteDb) {
        const { CredentialsManager } = require('./services/CredentialsManager');
        const cm = CredentialsManager.getInstance();
        const openaiKey = cm.getOpenaiApiKey() || process.env.OPENAI_API_KEY;
        const geminiKey = cm.getGeminiApiKey() || process.env.GOOGLE_API_KEY;

        this.ragManager = new RAGManager({
          db: sqliteDb,
          dbPath: db.getDbPath(),
          extPath: db.getExtPath(),
          openaiKey,
          geminiKey,
          ollamaUrl: process.env.OLLAMA_URL || 'http://localhost:11434'
        });
        this.ragManager.setLLMHelper(this.processingHelper.getLLMHelper());
        console.log('[AppState] RAGManager initialized');
      }
    } catch (error) {
      console.error('[AppState] Failed to initialize RAGManager:', error);
    }

    // Initialize Knowledge Orchestrator
    try {
      const db = DatabaseManager.getInstance();
      const sqliteDb = db.getDb();

      if (sqliteDb && KnowledgeDatabaseManagerClass && KnowledgeOrchestratorClass) {
        const knowledgeDb = new KnowledgeDatabaseManagerClass(sqliteDb);
        this.knowledgeOrchestrator = new KnowledgeOrchestratorClass(knowledgeDb);

        // Wire up LLM functions
        const llmHelper = this.processingHelper.getLLMHelper();

        // generateContent function for LLM calls
        this.knowledgeOrchestrator.setGenerateContentFn(async (contents: any[]) => {
          console.log("--> generateContent knowledgeOrchestrator: ", contents[0]?.text);
          return await llmHelper.generateContentStructured(
            contents[0]?.text || ''
          );
        });

        // Embedding function — lazily delegate to the cascaded EmbeddingPipeline
        // (OpenAI → Gemini → Ollama → Local bundled model).
        // We await waitForReady() so uploads during boot wait for the pipeline
        // instead of immediately throwing 'not ready'.
        const self = this;
        this.knowledgeOrchestrator.setEmbedFn(async (text: string) => {
          const pipeline = self.ragManager?.getEmbeddingPipeline();
          if (!pipeline) throw new Error('RAG pipeline not available');
          await pipeline.waitForReady();
          return await pipeline.getEmbedding(text);
        });
        if (typeof this.knowledgeOrchestrator.setEmbedQueryFn === 'function') {
          this.knowledgeOrchestrator.setEmbedQueryFn(async (text: string) => {
            const pipeline = self.ragManager?.getEmbeddingPipeline();
            if (!pipeline) throw new Error('RAG pipeline not available');
            await pipeline.waitForReady();
            return await pipeline.getEmbeddingForQuery(text);
          });
        }

        // Attach KnowledgeOrchestrator to LLMHelper
        llmHelper.setKnowledgeOrchestrator(this.knowledgeOrchestrator);

        console.log('[AppState] KnowledgeOrchestrator initialized');

        // ── Company context startup hydration ──────────────────────────────────────
        // Load persisted company context from DB and hydrate the orchestrator so it
        // becomes the single in-memory source of truth from the first request onward.
        try {
          const { hydrateOrchestratorFromContext } = require('./utils/companyKnowledge');
          const companyCtx = DatabaseManager.getInstance().getCompanyContext();
          if (companyCtx) {
            hydrateOrchestratorFromContext(this.knowledgeOrchestrator, companyCtx);
            console.log('[AppState] Orchestrator hydrated from DB on startup');
          } else {
            console.log('[AppState] No persisted company context found — orchestrator starts empty');
          }
        } catch (hydrateErr: any) {
          console.warn('[AppState] Startup orchestrator hydration failed (non-fatal):', hydrateErr.message);
        }

        // ── Restore persisted knowledge mode toggle ─────────────────────────────────
        try {
          const { CredentialsManager } = require('./services/CredentialsManager');
          const savedMode = CredentialsManager.getInstance().getKnowledgeModeActive();
          if (savedMode) {
            this.knowledgeOrchestrator.setKnowledgeMode(true);
            console.log('[AppState] Knowledge mode restored from saved preferences: ON');
          }
        } catch (modeErr: any) {
          console.warn('[AppState] Failed to restore knowledge mode (non-fatal):', modeErr.message);
        }
        // ── End startup hydration ───────────────────────────────────────────────────

      }
    } catch (error) {
      console.error('[AppState] Failed to initialize KnowledgeOrchestrator:', error);
    }
  }

  // Pure computation — does NOT set _builtinOnlyMode.
  // Use this in contexts that should not affect the meeting-mode flag (e.g. audio test).
  private _isBuiltinOnly(inputDeviceId?: string, outputDeviceId?: string): boolean {
    return AudioDevices.isBuiltinOnly(inputDeviceId, outputDeviceId);
  }

  // Echo pipeline mode for the native gate ('legacy' | 'phase1' | 'full_duplex').
  // Persisted in CredentialsManager; NATIVELY_ECHO_MODE env var wins for field debugging.
  private _echoMode(): string {
    try {
      const { CredentialsManager } = require('./services/CredentialsManager');
      return CredentialsManager.getInstance().getEchoPipelineMode();
    } catch {
      return 'full_duplex';
    }
  }

  private _shouldDisableMicVad(inputDeviceId?: string, outputDeviceId?: string): boolean {
    const builtinOnly = this._isBuiltinOnly(inputDeviceId, outputDeviceId);
    if (builtinOnly) {
      console.log(
        '[Main] Built-in mic + speakers detected: disabling local VAD on MicrophoneCapture ' +
        '(macOS AEC attenuates signal — Deepgram cloud VAD will handle silence detection)'
      );
    } else {
      console.log(
        '[Main] External audio device detected: local VAD remains active on MicrophoneCapture'
      );
    }
    this._builtinOnlyMode = builtinOnly;
    return builtinOnly;
  }

  private setupAutoUpdater(): void {
    autoUpdater.autoDownload = false
    autoUpdater.autoInstallOnAppQuit = false  // Manual install only via button

    // Default to latest (stable) channel - matches latest.yml generated by electron-builder
    autoUpdater.channel = 'latest'
    console.log(`[AutoUpdater] Channel: ${autoUpdater.channel}`)

    autoUpdater.on("checking-for-update", () => {
      console.log("[AutoUpdater] Checking for update...")
      this.broadcast("update-checking")
    })

    autoUpdater.on("update-available", async (info) => {
      console.log("[AutoUpdater] Update available:", info.version)
      this.updateAvailable = true

      // Fetch structured release notes
      const releaseManager = ReleaseNotesManager.getInstance();
      const notes = await releaseManager.fetchReleaseNotes(info.version);

      // Notify renderer that an update is available with parsed notes if available
      this.broadcast("update-available", {
        ...info,
        parsedNotes: notes
      })
    })

    autoUpdater.on("update-not-available", (info) => {
      console.log("[AutoUpdater] Update not available:", info.version)
      this.broadcast("update-not-available", info)
    })

    autoUpdater.on("error", (err) => {
      console.error("[AutoUpdater] Error:", err)
      // Include more details in the error message for debugging
      const errorMessage = err.message || err.toString() || 'Unknown update error'
      this.broadcast("update-error", errorMessage)
    })

    autoUpdater.on("download-progress", (progressObj) => {
      let log_message = "Download speed: " + progressObj.bytesPerSecond
      log_message = log_message + " - Downloaded " + progressObj.percent + "%"
      log_message = log_message + " (" + progressObj.transferred + "/" + progressObj.total + ")"
      console.log("[AutoUpdater] " + log_message)
      this.broadcast("download-progress", progressObj)
    })

    autoUpdater.on("update-downloaded", (info) => {
      console.log("[AutoUpdater] Update downloaded:", info.version)
      // Notify renderer that update is ready to install
      this.broadcast("update-downloaded", info)
    })

    // Start checking for updates with a 10-second delay
    setTimeout(() => {
      if (process.env.NODE_ENV === "development") {
        console.log("[AutoUpdater] Development mode: Skipping auto check (use manual button)");
      } else {
        autoUpdater.checkForUpdatesAndNotify().catch(err => {
          console.error("[AutoUpdater] Failed to check for updates:", err);
        });
      }
    }, 10000);
  }

  private async checkForUpdatesManual(): Promise<void> {
    try {
      console.log('[AutoUpdater] Checking for updates manually via GitHub API...');
      const releaseManager = ReleaseNotesManager.getInstance();
      // Fetch latest release
      const notes = await releaseManager.fetchReleaseNotes('latest');

      if (notes) {
        const currentVersion = app.getVersion();
        const latestVersionTag = notes.version; // e.g., "v1.2.0" or "1.2.0"
        const latestVersion = latestVersionTag.replace(/^v/, '');

        console.log(`[AutoUpdater] Manual Check: Current=${currentVersion}, Latest=${latestVersion}`);

        if (this.isVersionNewer(currentVersion, latestVersion)) {
          console.log('[AutoUpdater] Manual Check: New version found!');
          this.updateAvailable = true;

          // Mock an info object compatible with electron-updater
          const info = {
            version: latestVersion,
            files: [] as any[],
            path: '',
            sha512: '',
            releaseName: notes.summary,
            releaseNotes: notes.fullBody
          };

          // Notify renderer
          this.broadcast("update-available", {
            ...info,
            parsedNotes: notes
          });
        } else {
          console.log('[AutoUpdater] Manual Check: App is up to date.');
          this.broadcast("update-not-available", { version: currentVersion });
        }
      }
    } catch (err) {
      console.error('[AutoUpdater] Manual update check failed:', err);
    }
  }

  private isVersionNewer(current: string, latest: string): boolean {
    // EC-01 fix: strip pre-release suffixes (e.g. "2.1.0-beta.1" → "2.1.0")
    // before splitting so Number() never returns NaN on comparison.
    const stripPre = (v: string) => v.replace(/-.*$/, '');
    const c = stripPre(current).split('.').map(Number);
    const l = stripPre(latest).split('.').map(Number);

    for (let i = 0; i < 3; i++) {
      const cv = c[i] || 0;
      const lv = l[i] || 0;
      if (lv > cv) return true;
      if (lv < cv) return false;
    }
    return false;
  }


  public async quitAndInstallUpdate(): Promise<void> {
    console.log('[AutoUpdater] quitAndInstall called - applying update...')

    // On macOS, unsigned apps can't auto-restart via quitAndInstall
    // Workaround: Open the folder containing the downloaded update so user can install manually
    if (process.platform === 'darwin') {
      try {
        // Get the downloaded update file path (e.g., .../Natively-1.0.9-mac.zip)
        const updateFile = (autoUpdater as any).downloadedUpdateHelper?.file
        console.log('[AutoUpdater] Downloaded update file:', updateFile)

        if (updateFile) {
          const updateDir = path.dirname(updateFile)
          // Open the directory containing the update in Finder
          await shell.openPath(updateDir)
          console.log('[AutoUpdater] Opened update directory:', updateDir)

          // Quit the app so user can install new version
          setTimeout(() => app.quit(), 1000)
          return
        }
      } catch (err) {
        console.error('[AutoUpdater] Failed to open update directory:', err)
      }
    }

    // Fallback to standard quitAndInstall (works on Windows/Linux or if signed)
    setImmediate(() => {
      try {
        autoUpdater.quitAndInstall(false, true)
      } catch (err) {
        console.error('[AutoUpdater] quitAndInstall failed:', err)
        app.exit(0)
      }
    })
  }

  public async checkForUpdates(): Promise<void> {
    console.log('[AutoUpdater] Manual check for updates requested')
    try {
      // In development mode, use manual GitHub API check (electron-updater skips in dev)
      if (process.env.NODE_ENV === "development") {
        await this.checkForUpdatesManual()
      } else {
        await autoUpdater.checkForUpdatesAndNotify()
      }
    } catch (err: any) {
      console.error('[AutoUpdater] checkForUpdates failed:', err)
      const errorMessage = err.message || err.toString() || 'Update check failed'
      this.broadcast("update-error", errorMessage)
    }
  }

  public downloadUpdate(): void {
    console.log('[AutoUpdater] Starting download...')
    try {
      // Errors during download are surfaced via autoUpdater.on("error") which
      // already broadcasts "update-error". Do not broadcast here to avoid duplicates.
      autoUpdater.downloadUpdate().catch(err => {
        console.error('[AutoUpdater] downloadUpdate failed:', err)
      })
    } catch (err: any) {
      console.error('[AutoUpdater] downloadUpdate exception:', err)
    }
  }

  // New Property for System Audio & Microphone
  private systemAudioCapture: SystemAudioCapture | null = null;
  private microphoneCapture: MicrophoneCapture | null = null;
  private audioTestCapture: MicrophoneCapture | null = null; // For audio settings test
  private _audioTestStarting = false;               // P2-12: in-flight guard against concurrent calls
  private googleSTT: STTProvider | null = null; // Client
  private googleSTT_User: STTProvider | null = null; // User
  // Echo-pipeline telemetry poll (ERLE, gate state, mute ratio) — meeting-scoped.
  private _pipelineStatsTimer: NodeJS.Timeout | null = null;

  // Last route_name seen in the pipeline stats poll — fallback key for the
  // AEC alignment seed lookup when getOutputRoute() is unavailable pre-start.
  private _lastStatsRouteName: string | null = null;

  private _startPipelineStatsPolling(): void {
    if (this._pipelineStatsTimer) return;
    const native = loadNativeModule();
    if (!native?.getAudioPipelineStats) return; // stale .node binary — no stats surface
    this._pipelineStatsTimer = setInterval(() => {
      try {
        const stats = native.getAudioPipelineStats!();
        console.log(`[AudioPipeline] ${stats} filter=${JSON.stringify(this._echoFilter.getStats())}`);
        this._maybePersistEchoAlignSeed(stats);
      } catch (e) {
        console.warn('[AudioPipeline] stats poll failed:', e);
      }
    }, 5000);
  }

  /**
   * Persist the converged AEC alignment offset per output route so the next
   * meeting on the same route starts pre-aligned (echoAlignSeedMs). SIGNED:
   * positive = render delayed, negative = capture delayed. No-op until the
   * native module reports `converged` + `applied_align_offset_ms`.
   */
  private _maybePersistEchoAlignSeed(statsJson: string): void {
    try {
      const stats = JSON.parse(statsJson);
      if (typeof stats?.route_name === 'string' && stats.route_name) {
        this._lastStatsRouteName = stats.route_name;
      }
      const offset = stats?.applied_align_offset_ms;
      if (stats?.converged !== true || typeof offset !== 'number' || !Number.isFinite(offset)) return;
      const routeName = this._lastStatsRouteName;
      if (!routeName) return;
      const backend = typeof stats?.render_backend === 'string' ? stats.render_backend : 'unknown';
      if (CredentialsManager.getInstance().getEchoAlignSeed(routeName) !== offset) {
        CredentialsManager.getInstance().setEchoAlignSeed(routeName, offset, backend);
      }
    } catch {
      // Telemetry parsing must never disturb the audio pipeline.
    }
  }

  /**
   * Look up a persisted AEC alignment seed for the current output route.
   * Route name comes from native getOutputRoute() when available pre-start,
   * else the last stats sample; no route → no seed.
   */
  private _lookupEchoAlignSeed(): number | undefined {
    try {
      let routeName: string | undefined;
      const native = loadNativeModule();
      if (native?.getOutputRoute) {
        try {
          routeName = native.getOutputRoute().name || undefined;
        } catch { /* fall through to last stats sample */ }
      }
      if (!routeName) routeName = this._lastStatsRouteName ?? undefined;
      if (!routeName) return undefined;
      const seed = CredentialsManager.getInstance().getEchoAlignSeed(routeName);
      if (seed !== undefined) {
        console.log(`[Main] Echo align seed found for route "${routeName}": ${seed}ms`);
      }
      return seed;
    } catch {
      return undefined; // fail-open — capture starts unseeded
    }
  }

  private _stopPipelineStatsPolling(): void {
    if (this._pipelineStatsTimer) {
      clearInterval(this._pipelineStatsTimer);
      this._pipelineStatsTimer = null;
    }
  }

  // Transcript-level echo suppression (safety net behind the native AEC/gate).
  // Word-timestamp based when Deepgram word data is available — can TRIM just
  // the echoed words out of a mic segment instead of dropping it whole — with
  // the legacy n-gram text fallback for providers without word data.
  // Finals are dropped/trimmed; INTERIMS are suppressed (never trimmed) so
  // echo residue never flashes in the live UI. Thresholds tighten while the
  // native AEC is unconverged with the speaker active (getAecTelemetry).
  // echoPossible defaults to macOS only (Windows WASAPI setups show no bleed).
  private _echoFilter = new TranscriptEchoFilter({
    useWordFilter: () => {
      try {
        const { CredentialsManager } = require('./services/CredentialsManager');
        return CredentialsManager.getInstance().getEchoWordFilterEnabled();
      } catch {
        return true;
      }
    },
    isBuiltinOnly: () => this._builtinOnlyMode,
    getAecTelemetry: () => this._getAecTelemetry(),
  });

  // True while the renderer shows an un-finalized user partial — a dropped
  // echo final then needs an explicit retraction event to clear it.
  private _userPartialPending = false;

  // 500ms-cached parse of the native pipeline stats for the echo filter's
  // adaptive strictness. Any failure → null (fail-open: never strict).
  private _aecTelemetryCache: { at: number; value: AecTelemetry | null } | null = null;

  private _getAecTelemetry(): AecTelemetry | null {
    const now = Date.now();
    if (this._aecTelemetryCache && now - this._aecTelemetryCache.at < 500) {
      return this._aecTelemetryCache.value;
    }
    let value: AecTelemetry | null = null;
    try {
      const raw = loadNativeModule()?.getAudioPipelineStats?.();
      if (raw) {
        const stats = JSON.parse(raw);
        if (typeof stats?.gate_state === 'string') {
          value = {
            gateState: stats.gate_state,
            speakerActive: stats.speaker_active === true,
            erleDb: typeof stats.erle_db === 'number' ? stats.erle_db : undefined,
          };
        }
      }
    } catch {
      value = null;
    }
    this._aecTelemetryCache = { at: now, value };
    return value;
  }

  // _builtinOnlyMode: true when built-in speakers + mic are in use (no external device).
  // Used by _isMicEcho to apply a lower similarity threshold and by audio init to
  // set vadDisabled=true on MicrophoneCapture. AEC in the Rust DSP layer handles the
  // physical echo; no JS-side RMS gate is needed.
  private _builtinOnlyMode: boolean = false;

  // Distinct diarization speaker indices observed on the client stream this
  // meeting. Display labels get a "· Speaker n" suffix only once 2+ are seen,
  // so 1:1 calls render exactly as before diarization existed.
  private _clientSpeakerIndicesSeen: Set<number> = new Set();

  private createSTTProvider(speaker: 'client' | 'user'): STTProvider {
    const { CredentialsManager } = require('./services/CredentialsManager');
    const sttProvider = CredentialsManager.getInstance().getSttProvider();
    const sttLanguage = CredentialsManager.getInstance().getSttLanguage();

    let stt: STTProvider;

    if (sttProvider === 'deepgram') {
      const apiKey = CredentialsManager.getInstance().getDeepgramApiKey();
      if (apiKey) {
        // Diarization only on the client (system-audio) stream: the mic is
        // single-speaker by role, and diarize is a paid streaming add-on.
        const diarize = speaker === 'client'
          && CredentialsManager.getInstance().getDiarizeClientEnabled();
        console.log(`[Main] Using DeepgramStreamingSTT for ${speaker}${diarize ? ' (diarize on)' : ''}`);
        stt = new DeepgramStreamingSTT(apiKey, speaker, { diarize });
      } else {
        console.warn(`[Main] No API key for Deepgram STT, falling back to GoogleSTT`);
        stt = new GoogleSTT();
      }
    } else if (sttProvider === 'soniox') {
      const apiKey = CredentialsManager.getInstance().getSonioxApiKey();
      if (apiKey) {
        console.log(`[Main] Using SonioxStreamingSTT for ${speaker}`);
        stt = new SonioxStreamingSTT(apiKey);
      } else {
        console.warn(`[Main] No API key for Soniox STT, falling back to GoogleSTT`);
        stt = new GoogleSTT();
      }
    } else if (sttProvider === 'elevenlabs') {
      const apiKey = CredentialsManager.getInstance().getElevenLabsApiKey();
      if (apiKey) {
        console.log(`[Main] Using ElevenLabsStreamingSTT for ${speaker}`);
        stt = new ElevenLabsStreamingSTT(apiKey);
      } else {
        console.warn(`[Main] No API key for ElevenLabs STT, falling back to GoogleSTT`);
        stt = new GoogleSTT();
      }
    } else if (sttProvider === 'openai') {
      // OpenAI: WebSocket Realtime (gpt-4o-transcribe → gpt-4o-mini-transcribe) with whisper-1 REST fallback
      const apiKey = CredentialsManager.getInstance().getOpenAiSttApiKey();
      if (apiKey) {
        console.log(`[Main] Using OpenAIStreamingSTT (WebSocket+REST fallback) for ${speaker}`);
        stt = new OpenAIStreamingSTT(apiKey);
      } else {
        console.warn(`[Main] No API key for OpenAI STT, falling back to GoogleSTT`);
        stt = new GoogleSTT();
      }
    } else if (sttProvider === 'groq' || sttProvider === 'azure' || sttProvider === 'ibmwatson') {
      let apiKey: string | undefined;
      let region: string | undefined;
      let modelOverride: string | undefined;

      if (sttProvider === 'groq') {
        apiKey = CredentialsManager.getInstance().getGroqSttApiKey();
        modelOverride = CredentialsManager.getInstance().getGroqSttModel();
      } else if (sttProvider === 'azure') {
        apiKey = CredentialsManager.getInstance().getAzureApiKey();
        region = CredentialsManager.getInstance().getAzureRegion();
      } else if (sttProvider === 'ibmwatson') {
        apiKey = CredentialsManager.getInstance().getIbmWatsonApiKey();
        region = CredentialsManager.getInstance().getIbmWatsonRegion();
      }

      if (apiKey) {
        console.log(`[Main] Using RestSTT (${sttProvider}) for ${speaker}`);
        stt = new RestSTT(sttProvider, apiKey, modelOverride, region);
      } else {
        console.warn(`[Main] No API key for ${sttProvider} STT, falling back to GoogleSTT`);
        stt = new GoogleSTT();
      }
    } else {
      stt = new GoogleSTT();
    }

    stt.setRecognitionLanguage(sttLanguage);

    // Wire Transcript Events
    stt.on('transcript', (segment: {
      text: string, isFinal: boolean, confidence: number,
      speakerIndex?: number, words?: SttWord[]
    }) => {
      console.log(`[Main] STT transcript (${speaker}, final=${segment.isFinal}): "${segment.text}"`);
      if (!this.isMeetingActive) {
        console.warn(`[Main] Dropping transcript — meeting not active (speaker=${speaker})`);
        return;
      }

      if (this.isMeetingPaused) {
        return; // Drop transcript segments received during pause (rare, in-flight audio)
      }

      // Mic INTERIMS are judged first: leaked far-end speech must never flash
      // in the live UI or linger in SessionTracker's pending-interim slot.
      // Suppress-or-pass only — a suppressed interim is simply superseded.
      if (speaker === 'user' && !segment.isFinal) {
        const verdict = this._echoFilter.filterUserInterim(segment.text, segment.words);
        if (verdict.action === 'suppress') {
          console.log(`[Main] Suppressing mic echo interim (${verdict.method}, ratio=${verdict.matchRatio.toFixed(2)}${verdict.strict ? ', strict' : ''}): "${segment.text}"`);
          return;
        }
      }

      // On macOS with external speakers the mic physically hears the speakers,
      // causing the other party's speech to appear in both channels. Filter
      // mic (user) finals against recent client finals: word-timestamp matching
      // can trim just the echoed span; the n-gram fallback drops whole segments.
      if (speaker === 'user' && segment.isFinal) {
        const verdict = this._echoFilter.filterUserFinal(segment.text, segment.words);
        if (verdict.action === 'drop') {
          console.log(`[Main] Suppressing mic echo (${verdict.method}, ratio=${verdict.matchRatio.toFixed(2)}${verdict.strict ? ', strict' : ''}): "${segment.text}"`);
          // Clear SessionTracker's pending user interim so flushInterimTranscript()
          // can't persist the echo on stop: final:true clears lastInterimUser
          // and the empty text is ignored by addTranscript.
          this.intelligenceManager.handleTranscript({
            speaker: 'user',
            text: '',
            timestamp: Date.now(),
            final: true,
            confidence: 0
          });
          // If the renderer still shows a user partial, retract it — that
          // partial was (or fed into) the echo final we just dropped.
          if (this._userPartialPending) {
            const helper = this.getWindowHelper();
            const speakerNameMap = this.intelligenceManager.getSpeakerNameMap();
            const retraction = {
              speaker: 'user',
              displayName: speakerNameMap.user || 'Me',
              text: '',
              timestamp: Date.now(),
              final: false,
              retract: true
            };
            helper.getLauncherWindow()?.webContents.send('native-audio-transcript', retraction);
            helper.getOverlayWindow()?.webContents.send('native-audio-transcript', retraction);
            this._userPartialPending = false;
            this._echoFilter.noteRetractionEmitted();
          }
          return;
        }
        if (verdict.action === 'trim') {
          console.log(`[Main] Trimming mic echo (ratio=${verdict.matchRatio.toFixed(2)}${verdict.strict ? ', strict' : ''}): "${segment.text}" → "${verdict.text}"`);
          segment.text = verdict.text;
          segment.words = verdict.keptWords;
        }
      }

      // Record final client transcripts so mic echo detection has a reference window.
      if (speaker === 'client' && segment.isFinal) {
        this._echoFilter.addClientFinal(segment.text, segment.words);
      }

      // Client INTERIMS become the provisional echo reference — this closes
      // the ordering gap where mic echo lands before the client final does
      // (VAD-lockout restarts delay client finals, not client interims).
      if (speaker === 'client' && !segment.isFinal) {
        this._echoFilter.addClientInterim(segment.text, segment.words);
      }

      // Track distinct diarized far-end speakers. Labels only appear once a
      // SECOND speaker is confirmed — 1:1 calls render exactly as before.
      if (speaker === 'client' && segment.isFinal && segment.speakerIndex !== undefined) {
        this._clientSpeakerIndicesSeen.add(segment.speakerIndex);
      }

      this.intelligenceManager.handleTranscript({
        speaker: speaker,
        text: segment.text,
        timestamp: Date.now(),
        final: segment.isFinal,
        confidence: segment.confidence,
        speakerIndex: segment.speakerIndex
      });

      // Feed final transcript to JIT RAG indexer
      if (segment.isFinal && this.ragManager) {
        this.ragManager.feedLiveTranscript([{
          speaker: speaker,
          text: segment.text,
          timestamp: Date.now()
        }]);
      }

      const helper = this.getWindowHelper();
      // Resolve real display name at emit-time so the renderer always gets
      // a human-readable label, even before a speaker-names-resolved event fires.
      const speakerNameMap = this.intelligenceManager.getSpeakerNameMap();
      let displayName = speaker === 'user'
        ? (speakerNameMap.user || 'Me')
        : (speakerNameMap.client || 'Them');
      if (
        speaker === 'client' &&
        segment.speakerIndex !== undefined &&
        this._clientSpeakerIndicesSeen.size >= 2
      ) {
        displayName = `${displayName} · Speaker ${segment.speakerIndex + 1}`;
      }
      const payload = {
        speaker: speaker,          // internal role — kept for renderer routing logic
        displayName: displayName,  // resolved human name for UI display
        text: segment.text,
        timestamp: Date.now(),
        final: segment.isFinal,
        confidence: segment.confidence,
        speakerIndex: segment.speakerIndex
        // NOTE: segment.words stays main-process internal (echo filter input) —
        // deliberately NOT serialized into the 10+/sec IPC stream.
      };
      helper.getLauncherWindow()?.webContents.send('native-audio-transcript', payload);
      helper.getOverlayWindow()?.webContents.send('native-audio-transcript', payload);

      // Track whether the renderer's latest user event is an un-finalized
      // partial — an echo-dropped final must then retract it explicitly.
      if (speaker === 'user') {
        this._userPartialPending = !segment.isFinal;
      }

      // Feed final recruiter (system audio) transcripts to negotiation tracker
      if (segment.isFinal && speaker === 'client') {
        this.knowledgeOrchestrator?.feedInterviewerUtterance?.(segment.text);
      }
    });

    stt.on('error', (err: Error) => {
      console.error(`[Main] STT (${speaker}) Error:`, err);
    });

    return stt;
  }

  private setupSystemAudioPipeline(inputDeviceId?: string, outputDeviceId?: string): void {
    // REMOVED EARLY RETURN: if (this.systemAudioCapture && this.microphoneCapture) return; // Already initialized

    try {
      // 1. Initialize Captures if missing.
      // If they already exist (e.g. from reconfigureAudio) they are already
      // wired to write to this.googleSTT / googleSTT_User.

      if (!this.systemAudioCapture) {
        this.systemAudioCapture = new SystemAudioCapture(undefined, { echoMode: this._echoMode() });
        // Wire Capture -> STT
        this.systemAudioCapture.on('data', (chunk: Buffer) => {
          this.googleSTT?.write(chunk);
        });
        this.systemAudioCapture.on('speech_ended', () => {
          this.googleSTT?.notifySpeechEnded?.();
        });
        this.systemAudioCapture.on('error', (err: Error) => {
          console.error('[Main] SystemAudioCapture Error:', err);
          // Surface SCK permission failures (macOS) to the user so they know to grant
          // Screen Recording access in System Settings > Privacy & Security.
          this.broadcast('meeting-audio-warning', err.message || 'System audio capture failed');
        });
        // Re-sync STT sample rate when the native hardware rate is discovered post-start
        this.systemAudioCapture.on('sample-rate-detected', (rate: number) => {
          console.log(`[Main] System audio true rate detected: ${rate}Hz — resyncing STT`);
          this.googleSTT?.setSampleRate(rate);
        });
      }

      if (!this.microphoneCapture) {
        const disableMicVad = this._shouldDisableMicVad(inputDeviceId, outputDeviceId);
        this.microphoneCapture = new MicrophoneCapture(undefined, {
          vadDisabled: disableMicVad,
          echoMode: this._echoMode(),
          echoAlignSeedMs: this._lookupEchoAlignSeed()
        });
        this.microphoneCapture.on('data', (chunk: Buffer) => {
          this.googleSTT_User?.write(chunk);
        });
        this.microphoneCapture.on('speech_ended', () => {
          this.googleSTT_User?.notifySpeechEnded?.();
        });
        this.microphoneCapture.on('error', (err: Error) => {
          console.error('[Main] MicrophoneCapture Error:', err);
        });
        this.microphoneCapture.on('sample-rate-detected', (rate: number) => {
          console.log(`[Main] Mic true rate detected: ${rate}Hz — resyncing User STT`);
          this.googleSTT_User?.setSampleRate(rate);
        });
      }

      // 2. Initialize STT Services if missing
      if (!this.googleSTT) {
        this.googleSTT = this.createSTTProvider('client');
      }

      if (!this.googleSTT_User) {
        this.googleSTT_User = this.createSTTProvider('user');
      }

      // 3. Sync sample rates (pre-start best-effort; settle poll in startMeeting
      //    will override these once the hardware reports real values).
      const sysRate = this.systemAudioCapture?.getOutputSampleRate() || 16000;
      if (this._verboseLogging) console.log(`[Main] Configuring Client STT to ${sysRate}Hz`);
      this.googleSTT?.setSampleRate(sysRate);
      this.googleSTT?.setAudioChannelCount?.(1);

      const micRate = this.microphoneCapture?.getOutputSampleRate() || 16000;
      if (this._verboseLogging) console.log(`[Main] Configuring User STT to ${micRate}Hz`);
      this.googleSTT_User?.setSampleRate(micRate);
      this.googleSTT_User?.setAudioChannelCount?.(1);

      if (this._verboseLogging) console.log('[Main] Full Audio Pipeline (System + Mic) Initialized (Ready)');

    } catch (err) {
      console.error('[Main] Failed to setup System Audio Pipeline:', err);
    }
  }

  private async reconfigureAudio(inputDeviceId?: string, outputDeviceId?: string): Promise<void> {
    console.log(`[Main] Reconfiguring Audio: Input=${inputDeviceId}, Output=${outputDeviceId}`);

    // Determine VAD mode once upfront for this device combination.
    const disableMicVad = this._shouldDisableMicVad(inputDeviceId, outputDeviceId);

    // ── 1. System Audio (Output Capture) ──────────────────────────────────────
    if (this.systemAudioCapture) {
      this.systemAudioCapture.stop();
      this.systemAudioCapture = null;
    }

    const wireSystemAudio = (capture: typeof this.systemAudioCapture) => {
      if (!capture) return;
      capture.on('data', (chunk: Buffer) => {
        this.googleSTT?.write(chunk);
      });
      capture.on('speech_ended', () => {
        this.googleSTT?.notifySpeechEnded?.();
      });
      capture.on('error', (err: Error) => {
        console.error('[Main] SystemAudioCapture Error:', err);
      });
      capture.on('sample-rate-detected', (rate: number) => {
        console.log(`[Main] System audio true rate detected: ${rate}Hz — resyncing STT`);
        this.googleSTT?.setSampleRate(rate);
      });
    };

    try {
      console.log('[Main] Initializing SystemAudioCapture...');
      this.systemAudioCapture = new SystemAudioCapture(outputDeviceId || undefined, { echoMode: this._echoMode() });
      wireSystemAudio(this.systemAudioCapture);
      console.log('[Main] SystemAudioCapture initialized.');
    } catch (err) {
      console.warn('[Main] Failed to initialize SystemAudioCapture with preferred device. Falling back to default.', err);
      try {
        this.systemAudioCapture = new SystemAudioCapture(undefined, { echoMode: this._echoMode() });
        wireSystemAudio(this.systemAudioCapture);
        console.log('[Main] SystemAudioCapture (Default) initialized.');
      } catch (err2) {
        console.error('[Main] Failed to initialize SystemAudioCapture (Default):', err2);
      }
    }

    // ── 2. Microphone (Input Capture) ─────────────────────────────────────────
    if (this.microphoneCapture) {
      this.microphoneCapture.stop();
      this.microphoneCapture = null;
    }

    const wireMicrophone = (capture: typeof this.microphoneCapture) => {
      if (!capture) return;
      capture.on('data', (chunk: Buffer) => {
        this.googleSTT_User?.write(chunk);
      });
      capture.on('speech_ended', () => {
        this.googleSTT_User?.notifySpeechEnded?.();
      });
      capture.on('error', (err: Error) => {
        console.error('[Main] MicrophoneCapture Error:', err);
      });
      capture.on('sample-rate-detected', (rate: number) => {
        console.log(`[Main] Mic true rate detected: ${rate}Hz — resyncing User STT`);
        this.googleSTT_User?.setSampleRate(rate);
      });
    };

    const echoAlignSeedMs = this._lookupEchoAlignSeed();
    try {
      console.log('[Main] Initializing MicrophoneCapture...');
      this.microphoneCapture = new MicrophoneCapture(
        inputDeviceId || undefined,
        { vadDisabled: disableMicVad, echoMode: this._echoMode(), echoAlignSeedMs }
      );
      wireMicrophone(this.microphoneCapture);
      console.log('[Main] MicrophoneCapture initialized.');
    } catch (err) {
      console.warn('[Main] Failed to initialize MicrophoneCapture with preferred device. Falling back to default.', err);
      try {
        this.microphoneCapture = new MicrophoneCapture(
          undefined,
          { vadDisabled: disableMicVad, echoMode: this._echoMode(), echoAlignSeedMs }  // preserve VAD mode even on fallback
        );
        wireMicrophone(this.microphoneCapture);
        console.log('[Main] MicrophoneCapture (Default) initialized.');
      } catch (err2) {
        console.error('[Main] Failed to initialize MicrophoneCapture (Default):', err2);
      }
    }
  }

  /**
   * Reconfigure STT provider mid-session (called from IPC when user changes provider)
   * Destroys existing STT instances and recreates them with the new provider
   */
  public async reconfigureSttProvider(): Promise<void> {
    console.log('[Main] Reconfiguring STT Provider...');

    // RC-01 fix: pause audio captures FIRST so their EventEmitter queues drain
    // before we null-out the STT instances. Without this, buffered 'data' events
    // still in-flight call this.googleSTT?.write() while googleSTT is already null.
    if (this.isMeetingActive) {
      this.systemAudioCapture?.stop();
      this.microphoneCapture?.stop();
    }

    // Now safe to destroy STT instances — no more audio events incoming
    if (this.googleSTT) {
      this.googleSTT.stop();
      this.googleSTT.removeAllListeners();
      this.googleSTT = null;
    }
    if (this.googleSTT_User) {
      this.googleSTT_User.stop();
      this.googleSTT_User.removeAllListeners();
      this.googleSTT_User = null;
    }

    // Reinitialize the pipeline (will pick up the new provider from CredentialsManager)
    this.setupSystemAudioPipeline();

    // Restart STT first, then audio — same order as startMeeting to ensure
    // write() calls are not dropped while isActive=false.
    if (this.isMeetingActive) {
      this.googleSTT?.start();
      this.googleSTT_User?.start();
      this.systemAudioCapture?.start();
      this.microphoneCapture?.start();
    }

    console.log('[Main] STT Provider reconfigured');
  }


  public async startAudioTest(deviceId?: string): Promise<void> {
    // P2-12: guard against two concurrent calls both passing the async permission check
    // before either has created a capture — the second call would orphan the first capture.
    if (this._audioTestStarting) return;
    this._audioTestStarting = true;
    try {
      await this._startAudioTestImpl(deviceId);
    } finally {
      this._audioTestStarting = false;
    }
  }

  private async _startAudioTestImpl(deviceId?: string): Promise<void> {
    console.log(`[Main] Starting Audio Test on device: ${deviceId || 'default'}`);
    this.stopAudioTest(); // Stop any existing test

    if (!(await ensureMacMicrophoneAccess('audio test'))) {
      throw new Error('Microphone access denied. Please allow microphone access in System Settings and try again.');
    }

    const attachAudioTestListeners = (capture: MicrophoneCapture) => {
      capture.on('data', (chunk: Buffer) => {
        const targets = [
          this.settingsWindowHelper.getSettingsWindow(),
          this.getWindowHelper().getLauncherWindow(),
          this.getWindowHelper().getOverlayWindow(),
        ].filter((win): win is BrowserWindow => !!win && !win.isDestroyed());

        if (targets.length === 0) return;

        let sum = 0;
        const step = 10;
        const len = chunk.length;

        for (let i = 0; i < len; i += 2 * step) {
          const val = chunk.readInt16LE(i);
          sum += val * val;
        }

        const count = len / (2 * step);
        if (count > 0) {
          const rms = Math.sqrt(sum / count);
          const level = Math.min(rms / 10000, 1.0);
          for (const target of targets) {
            target.webContents.send('audio-test-level', level);
          }
        }
      });

      capture.on('error', (err: Error) => {
        console.error('[Main] AudioTest Error:', err);
      });
    };

    try {
      const testVadDisabled = this._isBuiltinOnly(deviceId, undefined);
      // Pass the route-keyed alignment seed here too: the native seed contract
      // is per-construction (omitted = clear), so an unseeded audio-test
      // constructor would wipe the pending seed of a concurrent meeting.
      this.audioTestCapture = new MicrophoneCapture(deviceId || undefined, {
        vadDisabled: testVadDisabled,
        echoMode: this._echoMode(),
        echoAlignSeedMs: this._lookupEchoAlignSeed()
      });
      attachAudioTestListeners(this.audioTestCapture);
      this.audioTestCapture.start();
    } catch (err) {
      console.warn('[Main] Failed to start audio test on preferred device. Falling back to default.', err);
      // RC-02 fix: explicitly stop and null the failed capture before creating
      // the fallback to prevent a brief double-microphone-capture window.
      try { this.audioTestCapture?.stop(); } catch { /* ignore errors on already-failed capture */ }
      this.audioTestCapture = null;
      try {
        this.audioTestCapture = new MicrophoneCapture(undefined, {
          vadDisabled: false, // fallback — unknown device, keep VAD
          echoMode: this._echoMode(),
          echoAlignSeedMs: this._lookupEchoAlignSeed()
        });
        attachAudioTestListeners(this.audioTestCapture);
        this.audioTestCapture.start();
      } catch (fallbackErr) {
        console.error('[Main] Failed to start audio test:', fallbackErr);
        throw fallbackErr;
      }
    }
  }

  public stopAudioTest(): void {
    if (this.audioTestCapture) {
      console.log('[Main] Stopping Audio Test');
      this.audioTestCapture.stop();
      this.audioTestCapture = null;
    }
  }

  public finalizeMicSTT(): void {
    // We only want to finalize the user microphone, because the context is Manual Answer
    if (this.googleSTT_User?.finalize) {
      console.log('[Main] Finalizing STT');
      this.googleSTT_User.finalize();
    }
  }


  public async startMeeting(metadata?: any): Promise<void> {
    console.log('[Main] Starting Meeting...', metadata);

    if (!(await ensureMacMicrophoneAccess('meeting start'))) {
      const message = 'Microphone access denied. Please allow microphone access in System Settings.';
      this.broadcast('meeting-audio-error', message);
      throw new Error(message);
    }

    this.isMeetingActive = true;
    this._pendingLiveAnalysisMeetingId = null;
    this._liveAnalysisInFlight = false;
    this._clientSpeakerIndicesSeen.clear();
    this._echoFilter.reset();
    this._userPartialPending = false;
    this.broadcastMeetingState();

    // Pass metadata directly to SessionTracker, which owns all name-resolution logic:
    // single attendee → real name, multiple → company-domain labeling, title fallback, etc.
    // Do NOT pre-resolve here — that would duplicate and potentially contradict SessionTracker.
    if (metadata) {
      this.intelligenceManager.setMeetingMetadata(metadata);
    }

    // Read back the names that SessionTracker just resolved and broadcast to renderer.
    // This runs unconditionally so the renderer always gets an update at meeting start,
    // even for manual meetings where metadata is undefined (defaults: Me / Them).
    // The 100 ms delay ensures the renderer's session-reset handler fires first.
    const resolvedNames = this.intelligenceManager.getSpeakerNameMap();
    setTimeout(() => {
      this.broadcast('speaker-names-resolved', resolvedNames);
    }, 100);

    // Emit session reset to clear UI state immediately
    this.getWindowHelper().getOverlayWindow()?.webContents.send('session-reset');
    this.getWindowHelper().getLauncherWindow()?.webContents.send('session-reset');

    // ★ ASYNC AUDIO INIT: Return INSTANTLY so the IPC response goes back
    // to the renderer immediately, allowing the UI to switch to overlay
    // without waiting for SCK/audio initialization (which takes 5-7 seconds).
    // setTimeout(0) ensures setWindowMode IPC is processed first.
    setTimeout(async () => {
      // BUG-02 fix: a fast start→stop sequence can call endMeeting() before
      // this callback fires, leaving isMeetingActive=false. If that happened,
      // do NOT boot the audio pipeline — it would run forever with no stop signal.
      if (!this.isMeetingActive) {
        console.warn('[Main] Meeting was cancelled before audio pipeline could start — aborting init.');
        return;
      }
      try {
        // Check for audio configuration preference
        if (metadata?.audio) {
          await this.reconfigureAudio(metadata.audio.inputDeviceId, metadata.audio.outputDeviceId);
        }

        // LAZY INIT: Ensure pipeline is ready (if not reconfigured above)
        this.setupSystemAudioPipeline();

        // Loopback-input guard (warn only): a virtual/loopback device as the
        // mic feeds far-end playback straight back as "user" speech — no echo
        // pipeline can fix a wired loop. Never refuse or auto-switch.
        try {
          const loopback = AudioDevices.detectLoopbackInput(metadata?.audio?.inputDeviceId);
          if (loopback.suspicious) {
            const message = `Microphone input "${loopback.deviceName}" looks like a loopback/virtual audio device — the other party's voice may be transcribed as yours. Consider selecting a physical microphone in Audio Settings.`;
            console.warn(`[Main] ${message}`);
            this.broadcast('meeting-audio-warning', message);
          }
        } catch { /* warn-only guard — never block meeting start */ }

        // Start STT BEFORE audio captures.
        // DeepgramStreamingSTT.write() silently drops chunks when isActive=false,
        // so if STT starts after the captures, all audio during the settle window
        // is lost and no client transcript is generated for early speech.
        // Starting with the 16000 fallback rate is safe: setSampleRate() after the
        // settle poll triggers _reconnectWithNewConfig() which reconnects with the
        // correct rate while preserving any buffered audio from the first connection.
        this.googleSTT?.setSampleRate(16000);
        this.googleSTT?.setAudioChannelCount?.(1);
        this.googleSTT_User?.setSampleRate(16000);
        this.googleSTT_User?.setAudioChannelCount?.(1);

        // Reset session timer here — not at the previous stopMeeting() — so that
        // duration = (stopTime − startTime) equals actual recording length only,
        // with no idle-between-meetings inflation.
        this.intelligenceManager.resetSessionTimer();

        this.googleSTT?.start();
        this.googleSTT_User?.start();

        // Start audio captures — data events now reach active STT connections immediately.
        this.systemAudioCapture?.start();
        this.microphoneCapture?.start();

        // Adaptive poll: wait until hardware reports real sample rates (or 2s timeout).
        // On macOS with SCK the background init thread can take 1-5s — the old fixed
        // 200ms window always read the stale 48000 default.
        let settledSysRate = 0;
        let settledMicRate = 0;

        await new Promise<void>(resolve => {
          let elapsed = 0;
          const POLL_INTERVAL_MS = 100;
          const POLL_TIMEOUT_MS = 2000;
          const DEFAULT_RATE = 0;

          const poll = setInterval(() => {
            elapsed += POLL_INTERVAL_MS;
            const sysRate = this.systemAudioCapture?.getOutputSampleRate() ?? DEFAULT_RATE;
            const micRate = this.microphoneCapture?.getOutputSampleRate() ?? DEFAULT_RATE;
            const sysReady = sysRate > 0 || elapsed >= POLL_TIMEOUT_MS;
            const micReady = micRate > 0 || elapsed >= POLL_TIMEOUT_MS;
            if (sysReady && micReady) {
              settledSysRate = sysRate;
              settledMicRate = micRate;
              clearInterval(poll);
              resolve();
            }
          }, POLL_INTERVAL_MS);
        });

        // Update rates now that hardware has reported them.
        // If different from the 16000 fallback used at start(), setSampleRate triggers
        // _reconnectWithNewConfig() which reconnects with the correct rate while
        // preserving buffered audio — no transcripts are lost.
        console.log(`[Main] Settled rates — sys: ${settledSysRate}Hz, mic: ${settledMicRate}Hz`);
        this.googleSTT?.setSampleRate(settledSysRate || 16000);
        this.googleSTT?.setAudioChannelCount?.(1);
        this.googleSTT_User?.setSampleRate(settledMicRate || 16000);
        this.googleSTT_User?.setAudioChannelCount?.(1);

        // Start JIT RAG live indexing
        if (this.ragManager) {
          this.ragManager.startLiveIndexing('live-meeting-current');
        }

        if (this._verboseLogging) {
          const requestedInput = metadata?.audio?.inputDeviceId || 'default';
          const requestedOutput = metadata?.audio?.outputDeviceId || 'default';
          const backend = requestedOutput === 'sck' ? 'sck' : 'coreaudio';
          const sysRate = this.systemAudioCapture?.getOutputSampleRate() || 16000;
          const micRate = this.microphoneCapture?.getOutputSampleRate() || 16000;
          console.log(`[Main][debug] Audio pipeline: input=${requestedInput} output=${requestedOutput} backend=${backend} sysRate=${sysRate}Hz micRate=${micRate}Hz`);
        }
        // Field telemetry for the echo pipeline (ERLE, gate state, mute ratio).
        this._startPipelineStatsPolling();
        console.log('[Main] Audio pipeline started successfully.');

      } catch (err) {
        console.error('[Main] Error initializing audio pipeline:', err);
        // Notify UI so user knows microphone/audio failed to start
        this.broadcast('meeting-audio-error', (err as Error).message || 'Audio pipeline failed to start');
      }
    }, 0); // Defer to next event loop tick — ensures IPC response reaches renderer before audio init
  }

  public async endMeeting(meetingTypes?: ('discovery' | 'demo' | 'negotiation')[], tenantId?: string | null): Promise<string | null> {
    console.log('[Main] Ending Meeting...');
    this.isMeetingActive = false; // Block new data immediately
    this.isMeetingPaused = false; // Reset pause flag — clean slate for next meeting
    this.broadcastMeetingState();
    this.broadcastMeetingPauseState(); // Notify renderers so they don't retain stale paused UI

    // Reset Mouse Passthrough so the next meeting overlay starts fresh and focusable
    if (this.overlayMousePassthrough) {
      this.setOverlayMousePassthrough(false);
    }

    // Stop audio captures synchronously — these are fire-and-forget internally
    this._stopPipelineStatsPolling();
    this.systemAudioCapture?.stop();
    this.googleSTT?.stop();
    this.microphoneCapture?.stop();
    this.googleSTT_User?.stop();

    // Save session state and reset context — MeetingPersistence.stopMeeting() is
    // already fire-and-forget internally (processAndSaveMeeting runs in background).
    // Capture the meetingId NOW so the background IIFE uses a deterministic ID
    // rather than getRecentMeetings(1) which could return a different meeting if the
    // user starts a new session before background processing finishes.
    const meetingId = await this.intelligenceManager.stopMeeting(meetingTypes, tenantId);
    // Tell the overlay window EXACTLY which meeting this call became — don't
    // make it infer this from getRecentMeetings()[0]. That list is sorted by
    // `date`, and MeetingPersistence rewrites `date` to "now" a SECOND time
    // when a meeting's background processing finishes (which can complete
    // well after a later call has already ended) — so an older meeting can
    // briefly outrank the current one in "most recent" order. This broadcast
    // is the one authoritative, race-free source for "which meeting did the
    // call I just ended turn into".
    if (meetingId) {
      this.broadcast('live-call-ended', { meetingId });
    }
    // If an analysis call is currently in-flight, record the meetingId so
    // setCurrentLiveAnalysis() can patch the DB when the result arrives.
    if (this._liveAnalysisInFlight) {
      this._pendingLiveAnalysisMeetingId = meetingId;
    }

    // Revert to Default Model — synchronous, no blocking I/O
    try {
      const { CredentialsManager } = require('./services/CredentialsManager');
      const cm = CredentialsManager.getInstance();
      const defaultModel = cm.getDefaultModel();
      const all = [...(cm.getCurlProviders() || []), ...(cm.getCustomProviders() || [])];
      console.log(`[Main] Reverting model to default: ${defaultModel}`);
      this.processingHelper.getLLMHelper().setModel(defaultModel, all);
      BrowserWindow.getAllWindows().forEach(win => {
        if (!win.isDestroyed()) win.webContents.send('model-changed', defaultModel);
      });
    } catch (e) {
      console.error('[Main] Failed to revert model:', e);
    }

    // ─── Background post-processing ──────────────────────────────────────────
    // These are the previously blocking operations that caused the stop-button
    // delay. They are pure background tasks with no UI dependency:
    //   • stopLiveIndexing flushes the JIT RAG live stream
    //   • processCompletedMeetingForRAG embeds the full meeting into the vector store
    //   • deleteMeetingData cleans up provisional JIT chunks
    // Chain them sequentially in the background so ordering is preserved,
    // but the IPC call returns immediately and the UI transitions without delay.
    const ragManager = this.ragManager;
    if (meetingId) {
      (async () => {
        try {
          if (ragManager) {
            await ragManager.stopLiveIndexing();
            console.log('[Main] Live RAG indexing stopped.');
          }
          await this.processCompletedMeetingForRAG(meetingId);
          // Guard: only delete live-meeting-current provisional chunks if no new
          // meeting has started while we were processing. If a new meeting IS active,
          // 'live-meeting-current' now belongs to that session — leave it alone.
          if (ragManager && !this.isMeetingActive) {
            ragManager.deleteMeetingData('live-meeting-current');
            console.log('[Main] JIT RAG provisional chunks cleaned up.');
          } else if (this.isMeetingActive) {
            console.log('[Main] New meeting started during cleanup — skipping live-meeting-current deletion.');
          }
        } catch (err) {
          console.error('[Main] Background post-meeting RAG processing failed:', err);
        }
      })();
    } else {
      // Meeting was too short — still flush the live indexer and clean up
      if (ragManager) {
        ragManager.stopLiveIndexing().catch(() => { });
        if (!this.isMeetingActive) ragManager.deleteMeetingData('live-meeting-current');
      }
    }
    // ─────────────────────────────────────────────────────────────────────────

    // Renderer needs this to call the FastAPI /meetings/:id/chunking endpoint
    // once the meeting is over (electron does its own local RAG chunking above
    // via processCompletedMeetingForRAG — this is a separate, backend-side ingest).
    return meetingId;

  }

  /**
   * Shows a custom toast notification on whichever display the main app window
   * currently lives on.
   *
   * WHY NOT electron.Notification?
   *   On Windows, native toast notifications are always delivered to the display
   *   that owns the primary taskbar — there is no Win32 API to redirect them to
   *   another monitor.  Briefly focusing the app window does not change this.
   *   The only reliable cross-platform solution is a frameless, transparent
   *   BrowserWindow that we explicitly position in the bottom-right corner of
   *   the target display ourselves.  This gives pixel-perfect control on every OS.
   *
   * Behaviour:
   *   - Appears bottom-right of whatever screen the main app window is on.
   *   - Never steals keyboard focus (showInactive).
   *   - Always-on-top so it is visible over full-screen meeting apps.
   *   - Auto-dismisses after `durationMs` (default 4 s) with a CSS fade-out.
   *   - If a toast is already showing, it is closed first so toasts don't pile up.
   */
  private _toastWindow: BrowserWindow | null = null;
  private _toastTimer: NodeJS.Timeout | null = null;

  private showNotificationOnActiveDisplay(
    title: string,
    body: string,
    _silent = true,          // kept for API compat; custom toast is always silent
    durationMs = 4000,
  ): void {
    // --- 1. Tear down any existing toast immediately ---
    if (this._toastTimer) {
      clearTimeout(this._toastTimer);
      this._toastTimer = null;
    }
    if (this._toastWindow && !this._toastWindow.isDestroyed()) {
      this._toastWindow.close();
      this._toastWindow = null;
    }

    // --- 2. Determine target display ---
    const mainWin = this.getMainWindow();
    let targetDisplay: Electron.Display;
    if (mainWin && !mainWin.isDestroyed()) {
      targetDisplay = screen.getDisplayMatching(mainWin.getBounds());
    } else {
      targetDisplay = screen.getPrimaryDisplay();
    }

    // --- 3. Calculate position: bottom-right corner, 16 px margin ---
    const TOAST_W = 320;
    const TOAST_H = 80;
    const MARGIN = 16;
    const { workArea } = targetDisplay;
    const toastX = workArea.x + workArea.width - TOAST_W - MARGIN;
    const toastY = workArea.y + workArea.height - TOAST_H - MARGIN;

    // --- 4. Build the toast HTML inline (no external file needed) ---
    const isMac = process.platform === 'darwin';
    const bgColor = isMac ? '#1e1e1e' : '#2b2b2b';   // match screenshot style
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
      *{margin:0;padding:0;box-sizing:border-box}
      html,body{width:100%;height:100%;overflow:hidden;background:transparent}
      .toast{
        position:absolute;inset:0;
        background:${bgColor};
        border-radius:8px;
        border:1px solid rgba(255,255,255,0.12);
        padding:12px 16px;
        display:flex;flex-direction:column;justify-content:center;gap:4px;
        font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
        color:#fff;
        box-shadow:0 4px 24px rgba(0,0,0,0.5);
        animation:fadeIn 0.2s ease;
      }
      .title{font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .body {font-size:12px;color:rgba(255,255,255,0.72);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      @keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
      @keyframes fadeOut{from{opacity:1}to{opacity:0}}
      .fading{animation:fadeOut 0.3s ease forwards}
    </style></head><body>
      <div class="toast" id="t">
        <div class="title">${title.replace(/</g, '&lt;')}</div>
        <div class="body">${body.replace(/</g, '&lt;')}</div>
      </div>
      <script>
        const FADE=300,STAY=${durationMs - 300};
        setTimeout(()=>{
          document.getElementById('t').classList.add('fading');
          setTimeout(()=>window.close(),FADE);
        },STAY);
      </script>
    </body></html>`;

    // --- 5. Create the toast BrowserWindow ---
    const toast = new BrowserWindow({
      width: TOAST_W,
      height: TOAST_H,
      x: toastX,
      y: toastY,
      frame: false,
      transparent: true,
      resizable: false,
      movable: false,
      focusable: false,
      skipTaskbar: true,
      alwaysOnTop: true,
      show: false,
      hasShadow: false,
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        // No preload needed — the toast is self-contained HTML
      },
    });

    // Apply content-protection so the toast is hidden from screen-capture
    // on the same surfaces as the main window.
    if (this.windowHelper.getContentProtection?.()) {
      toast.setContentProtection(true);
    }

    this._toastWindow = toast;

    toast.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`);

    toast.once('ready-to-show', () => {
      if (toast.isDestroyed()) return;
      toast.showInactive();           // never steal focus
    });

    toast.on('closed', () => {
      if (this._toastWindow === toast) this._toastWindow = null;
    });

    // --- 6. Hard-kill timer as safety net (CSS animation handles the visual fade) ---
    this._toastTimer = setTimeout(() => {
      this._toastTimer = null;
      if (this._toastWindow && !this._toastWindow.isDestroyed()) {
        this._toastWindow.close();
        this._toastWindow = null;
      }
    }, durationMs + 500);   // 500 ms grace for the CSS fade-out
  }

  public pauseMeeting(): void {
    if (!this.isMeetingActive) {
      console.warn('[Main] pauseMeeting() called but no meeting is active — ignoring.');
      return;
    }
    if (this.isMeetingPaused) {
      console.warn('[Main] pauseMeeting() called but meeting is already paused — ignoring.');
      return;
    }

    console.log('[Main] Pausing Meeting...');
    this.isMeetingPaused = true;
    this.intelligenceManager.recordPauseStart();

    // 1. Stop audio capture — drop incoming audio chunks on the floor.
    //    We call stop() (not destroy) so we can restart without re-initializing
    //    the capture objects. The STT streams stay alive but receive no new data.
    this.systemAudioCapture?.stop();
    this.microphoneCapture?.stop();

    // 2. Stop STT streams. They will be restarted on resume.
    //    GoogleSTT / DeepgramSTT / OpenAISTT all have .stop() + .start() lifecycle.
    this.googleSTT?.stop();
    this.googleSTT_User?.stop();

    // 3. Pause live RAG indexing so no partial sentences are embedded.
    //    RAGManager does not have a pause() API — we stop it; resume will restart it.
    if (this.ragManager) {
      this.ragManager.stopLiveIndexing().catch(() => { });
    }

    // 4. Broadcast pause state to all renderer windows.
    this.broadcastMeetingPauseState();

    // 5. Update tray menu to show paused state
    this.updateTrayMenu();

    // 6. Show a native OS notification so the user knows recording is paused.
    //    showNotificationOnActiveDisplay() ensures the notification appears on
    //    whichever monitor the app window currently occupies (e.g. an external
    //    display the user dragged the app to), not always the primary screen.
    this.showNotificationOnActiveDisplay(
      'Meeting Paused',
      'Audio capture and transcription are paused.',
    );

    console.log('[Main] Meeting paused. Audio capture and STT stopped.');
  }

  public async resumeMeeting(): Promise<void> {
    if (!this.isMeetingActive) {
      console.warn('[Main] resumeMeeting() called but no meeting is active — ignoring.');
      return;
    }
    if (!this.isMeetingPaused) {
      console.warn('[Main] resumeMeeting() called but meeting is not paused — ignoring.');
      return;
    }

    console.log('[Main] Resuming Meeting...');

    try {
      // FIX-3: Start STT FIRST so isActive=true and WebSocket is open before
      // the native Rust capture threads begin emitting data events.
      //
      // The previous order (audio start → STT start) had a race window where
      // the Rust DSP threads woke up and pushed chunks into the STT ring buffer
      // while both STT instances still had isActive=false.  When googleSTT.start()
      // and googleSTT_User.start() then fired, they each flushed their buffers —
      // but the system-audio chunks that arrived during the gap were non-deterministically
      // held in whichever STT instance connected first, causing speaker mismatch after
      // every pause/resume cycle.
      //
      // Correct order: STT open (isActive=true, WebSocket connecting) → audio start.
      // Chunks that arrive before the WebSocket handshake completes go into the STT
      // ring buffer which is flushed on 'open', still assigned to the correct instance.

      // 1. Re-sync rates in case the device changed while paused.
      const resumeSysRate = this.systemAudioCapture?.getOutputSampleRate() || 16000;
      const resumeMicRate = this.microphoneCapture?.getOutputSampleRate() || 16000;
      this.googleSTT?.setSampleRate(resumeSysRate);
      this.googleSTT?.setAudioChannelCount?.(1);
      this.googleSTT_User?.setSampleRate(resumeMicRate);
      this.googleSTT_User?.setAudioChannelCount?.(1);
      this.googleSTT?.start();
      this.googleSTT_User?.start();

      // 2. NOW start audio — data events go to already-active STT instances.
      this.systemAudioCapture?.start();
      this.microphoneCapture?.start();

      // 3. Resume live RAG indexing using the SAME session key 'live-meeting-current'
      //    so all new transcript segments are appended to the existing session,
      //    not a new one. No duplicate meeting ID is created.
      if (this.ragManager) {
        this.ragManager.startLiveIndexing('live-meeting-current');
      }

      // 4. Only clear the pause flag after the entire pipeline has successfully restarted.
      this.isMeetingPaused = false;
      this.intelligenceManager.recordPauseEnd();
    } catch (err) {
      console.error('[Main] Error resuming audio pipeline:', err);
      // Restore paused state so UI stays consistent with the actual pipeline state.
      this.isMeetingPaused = true;
      this.broadcast('meeting-audio-error', (err as Error).message || 'Audio failed to resume');
      this.broadcastMeetingPauseState();
      return;
    }

    // 5. Broadcast resumed state to all renderer windows only on success.
    this.broadcastMeetingPauseState();

    // 6. Update tray menu to remove paused state indicator
    this.updateTrayMenu();

    // 7. Native OS notification — meeting resumed.
    //    Same display-aware helper as pauseMeeting() above.
    this.showNotificationOnActiveDisplay(
      'Meeting Resumed',
      'Audio capture and transcription have resumed.',
    );

    console.log('[Main] Meeting resumed. Audio capture and STT restarted.');
  }

  public getCurrentLiveAnalysis(): LiveAnalysisData | null {
    return this._currentLiveAnalysis;
  }

  public setCurrentLiveAnalysis(data: LiveAnalysisData | null): void {
    this._currentLiveAnalysis = data;

    // If endMeeting() already ran and left a pending meetingId, this is a late-arriving
    // analysis result. Patch it directly into the saved meeting record in the DB.
    if (data && this._pendingLiveAnalysisMeetingId && !this.isMeetingActive) {
      const meetingId = this._pendingLiveAnalysisMeetingId;
      this._pendingLiveAnalysisMeetingId = null;
      try {
        const db = DatabaseManager.getInstance();
        const meeting = db.getMeetingDetails(meetingId);
        if (meeting) {
          const existing = meeting.detailedSummary || { actionItems: [], keyPoints: [] };
          db.updateMeeting(meetingId, {
            detailedSummary: { ...existing, liveAnalysis: data }
          });
          console.log(`[AppState] Late-arriving live analysis patched into meeting ${meetingId}`);
        }
      } catch (err) {
        console.error('[AppState] Failed to patch late live analysis:', err);
      }
    }
  }

  public clearCurrentLiveAnalysis(): void {
    this._currentLiveAnalysis = null;
    this._companyIntel = null;
  }

  private async processCompletedMeetingForRAG(meetingId: string): Promise<void> {
    if (!this.ragManager) return;

    try {
      // Use the explicit meetingId passed from endMeeting() — deterministic, never
      // picks up a concurrently started meeting the way getRecentMeetings(1) could.
      const meeting = DatabaseManager.getInstance().getMeetingDetails(meetingId);
      if (!meeting || !meeting.transcript || meeting.transcript.length === 0) return;

      // Convert transcript to RAG format
      const segments = meeting.transcript.map(t => ({
        speaker: t.speaker,
        text: t.text,
        timestamp: t.timestamp
      }));

      // Generate summary from detailedSummary if available
      let summary: string | undefined;
      if (meeting.detailedSummary) {
        summary = [
          ...(meeting.detailedSummary.keyPoints || []),
          ...(meeting.detailedSummary.actionItems || []).map(a => `Action: ${a}`)
        ].join('. ');
      }

      const result = await this.ragManager.processMeeting(meeting.id, segments, summary);
      console.log(`[AppState] RAG processed meeting ${meeting.id}: ${result.chunkCount} chunks`);

    } catch (error) {
      console.error('[AppState] Failed to process meeting for RAG:', error);
    }
  }

  private setupIntelligenceEvents(): void {
    const mainWindow = this.getMainWindow.bind(this)

    // Forward intelligence events to renderer
    this.intelligenceManager.on('assist_update', (insight: string) => {
      // Send to both if both exist, though mostly overlay needs it
      const helper = this.getWindowHelper();
      helper.getLauncherWindow()?.webContents.send('intelligence-assist-update', { insight });
      helper.getOverlayWindow()?.webContents.send('intelligence-assist-update', { insight });
    })

    this.intelligenceManager.on('what_am_i_missing_token', (token: string) => {
      const win = mainWindow();
      if (win) win.webContents.send('intelligence-what-am-i-missing-token', { token });
    });

    this.intelligenceManager.on('what_am_i_missing', (answer: string) => {
      const win = mainWindow();
      if (win) win.webContents.send('intelligence-what-am-i-missing', { answer });
    });

    this.intelligenceManager.on('discovery_token', (token: string) => {
      const win = mainWindow();
      if (win) win.webContents.send('intelligence-discovery-token', { token });
    });

    this.intelligenceManager.on('discovery', (answer: string) => {
      const win = mainWindow();
      if (win) win.webContents.send('intelligence-discovery', { answer });
    });

    this.intelligenceManager.on('objection_handler_token', (token: string) => {
      const win = mainWindow();
      if (win) win.webContents.send('intelligence-objection-handler-token', { token });
    });

    this.intelligenceManager.on('objection_handler', (answer: string) => {
      const win = mainWindow();
      if (win) win.webContents.send('intelligence-objection-handler', { answer });
    });

    this.intelligenceManager.on('suggested_answer', (answer: string, question: string, confidence: number) => {
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-suggested-answer', { answer, question, confidence })
      }

    })

    this.intelligenceManager.on('suggested_answer_token', (token: string, question: string, confidence: number) => {
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-suggested-answer-token', { token, question, confidence })
      }
    })

    this.intelligenceManager.on('refined_answer_token', (token: string, intent: string) => {
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-refined-answer-token', { token, intent })
      }
    })

    this.intelligenceManager.on('refined_answer', (answer: string, intent: string) => {
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-refined-answer', { answer, intent })
      }

    })

    this.intelligenceManager.on('recap', (summary: string) => {
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-recap', { summary })
      }
    })

    this.intelligenceManager.on('recap_token', (token: string) => {
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-recap-token', { token })
      }
    })

    this.intelligenceManager.on('clarify', (clarification: string) => {
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-clarify', { clarification })
      }
    })

    this.intelligenceManager.on('clarify_token', (token: string) => {
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-clarify-token', { token })
      }
    })

    this.intelligenceManager.on('follow_up_questions_update', (questions: string) => {
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-follow-up-questions-update', { questions })
      }
    })

    this.intelligenceManager.on('follow_up_questions_token', (token: string) => {
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-follow-up-questions-token', { token })
      }
    })

    this.intelligenceManager.on('manual_answer_started', () => {
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-manual-started')
      }
    })

    this.intelligenceManager.on('manual_answer_result', (answer: string, question: string) => {
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-manual-result', { answer, question })
      }

    })

    this.intelligenceManager.on('mode_changed', (mode: string) => {
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-mode-changed', { mode })
      }
    })

    this.intelligenceManager.on('speaker-names-resolved', (names: { user: string; client: string }) => {
      console.log('[AppState] Speaker names resolved, broadcasting to all windows:', names);
      BrowserWindow.getAllWindows().forEach(win => {
        if (!win.isDestroyed()) {
          win.webContents.send('speaker-names-resolved', names);
        }
      });
    });

    this.intelligenceManager.on('error', (error: Error, mode: string) => {
      console.error(`[IntelligenceManager] Error in ${mode}:`, error)
      const win = mainWindow()
      if (win) {
        win.webContents.send('intelligence-error', { error: error.message, mode })
      }
    })
  }





  public updateGoogleCredentials(keyPath: string): void {
    console.log(`[AppState] Updating Google Credentials to: ${keyPath}`);
    // Set global environment variable so new instances pick it up
    process.env.GOOGLE_APPLICATION_CREDENTIALS = keyPath;

    if (this.googleSTT) {
      this.googleSTT.setCredentials(keyPath);
    }

    if (this.googleSTT_User) {
      this.googleSTT_User.setCredentials(keyPath);
    }
  }

  public setRecognitionLanguage(key: string): void {
    console.log(`[AppState] Setting recognition language to: ${key}`);
    const { CredentialsManager } = require('./services/CredentialsManager');
    CredentialsManager.getInstance().setSttLanguage(key);
    this.googleSTT?.setRecognitionLanguage(key);
    this.googleSTT_User?.setRecognitionLanguage(key);
    this.processingHelper.getLLMHelper().setSttLanguage(key);
  }

  public static getInstance(): AppState {
    if (!AppState.instance) {
      AppState.instance = new AppState()
    }
    return AppState.instance
  }

  // Getters and Setters
  public getMainWindow(): BrowserWindow | null {
    return this.windowHelper.getMainWindow()
  }

  public getWindowHelper(): WindowHelper {
    return this.windowHelper
  }

  public getIntelligenceManager(): IntelligenceManager {
    return this.intelligenceManager
  }

  public getThemeManager(): ThemeManager {
    return this.themeManager
  }

  public getRAGManager(): RAGManager | null {
    return this.ragManager;
  }

  public getKnowledgeOrchestrator(): any {
    return this.knowledgeOrchestrator;
  }

  public getView(): "queue" | "solutions" {
    return this.view
  }

  public setView(view: "queue" | "solutions"): void {
    this.view = view
    this.screenshotHelper.setView(view)
  }

  public isVisible(): boolean {
    return this.windowHelper.isVisible()
  }

  public getScreenshotHelper(): ScreenshotHelper {
    return this.screenshotHelper
  }

  public getProblemInfo(): any {
    return this.problemInfo
  }

  public setProblemInfo(problemInfo: any): void {
    this.problemInfo = problemInfo
  }

  public getScreenshotQueue(): string[] {
    return this.screenshotHelper.getScreenshotQueue()
  }

  public getExtraScreenshotQueue(): string[] {
    return this.screenshotHelper.getExtraScreenshotQueue()
  }

  public getSpeakerNameMap(): { user: string; client: string } {
    return { ...this.speakerNameMap };
  }

  // Window management methods
  public setupOllamaIpcHandlers(): void {
    ipcMain.handle('get-ollama-models', async () => {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 2000); // 2s timeout for detection

        const response = await fetch('http://localhost:11434/api/tags', {
          signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (response.ok) {
          const data = await response.json();
          // data.models is an array of objects: { name: "llama3:latest", ... }
          return data.models.map((m: any) => m.name);
        }
        return [];
      } catch (error) {
        // console.warn("Ollama detection failed:", error);
        return [];
      }
    });
  }

  public createWindow(): void {
    this.windowHelper.createWindow()
  }

  public hideMainWindow(): void {
    this.windowHelper.hideMainWindow()
  }

  public showMainWindow(inactive?: boolean): void {
    if (this.windowHelper) {
      this.windowHelper.showMainWindow(inactive)
    }
  }

  public toggleMainWindow(): void {
    console.log(
      "Screenshots: ",
      this.screenshotHelper.getScreenshotQueue().length,
      "Extra screenshots: ",
      this.screenshotHelper.getExtraScreenshotQueue().length
    )

    const mode = this.windowHelper.getCurrentWindowMode();

    if (mode === 'launcher') {
      // In launcher mode, just physically hide/show the window
      this.windowHelper.toggleMainWindow();
    } else {
      // In overlay mode, send toggle-expand IPC to expand/collapse the UI
      const targetWindow = this.windowHelper.getOverlayWindow();
      if (targetWindow && !targetWindow.isDestroyed()) {
        targetWindow.webContents.send('toggle-expand');
      }
    }
  }

  public setWindowDimensions(width: number, height: number): void {
    this.windowHelper.setWindowDimensions(width, height)
  }

  public clearQueues(): void {
    this.screenshotHelper.clearQueues()

    // Clear problem info
    this.problemInfo = null

    // Reset view to initial state
    this.setView("queue")
  }

  private createScreenshotCaptureSession(
    captureKind: ScreenshotCaptureKind,
    restoreFocus: boolean
  ): ScreenshotCaptureSession {
    const settingsWindow = this.settingsWindowHelper.getSettingsWindow();
    const modelSelectorWindow = this.modelSelectorWindowHelper.getWindow();

    return {
      captureKind,
      wasMainWindowVisible: this.windowHelper.isVisible(),
      windowMode: this.windowHelper.getCurrentWindowMode(),
      wasSettingsVisible: !!settingsWindow && !settingsWindow.isDestroyed() && settingsWindow.isVisible(),
      wasModelSelectorVisible: !!modelSelectorWindow && !modelSelectorWindow.isDestroyed() && modelSelectorWindow.isVisible(),
      overlayBounds: this.windowHelper.getLastOverlayBounds(),
      overlayDisplayId: this.windowHelper.getLastOverlayDisplayId(),
      restoreWithoutFocus: process.platform === 'darwin' || !restoreFocus
    };
  }

  private getDisplayById(displayId: number | null): Electron.Display | undefined {
    if (displayId === null) return undefined;
    return screen.getAllDisplays().find(display => display.id === displayId);
  }

  private getTargetDisplayForFullScreenshot(session: ScreenshotCaptureSession): Electron.Display {
    if (session.windowMode === 'overlay' && session.overlayBounds) {
      return screen.getDisplayMatching(session.overlayBounds);
    }

    const lastOverlayDisplay = this.getDisplayById(session.overlayDisplayId);
    if (lastOverlayDisplay) {
      return lastOverlayDisplay;
    }

    return screen.getDisplayNearestPoint(screen.getCursorScreenPoint());
  }

  private hideWindowsForScreenshot(session: ScreenshotCaptureSession): void {
    if (session.wasModelSelectorVisible) {
      this.modelSelectorWindowHelper.hideWindow();
    }

    if (session.wasSettingsVisible) {
      this.settingsWindowHelper.closeWindow();
    }

    if (session.wasMainWindowVisible) {
      this.hideMainWindow();
    }
  }

  private restoreWindowsAfterScreenshot(session: ScreenshotCaptureSession): void {
    const activate = !session.restoreWithoutFocus;
    const shouldRestoreMainWindow = session.wasMainWindowVisible;

    if (shouldRestoreMainWindow) {
      if (session.windowMode === 'overlay') {
        this.windowHelper.switchToOverlay(!activate);
      } else {
        this.windowHelper.switchToLauncher(!activate);
      }
    }

    if (session.wasSettingsVisible) {
      const settingsWindow = this.settingsWindowHelper.getSettingsWindow();
      if (settingsWindow && !settingsWindow.isDestroyed()) {
        const { x, y } = settingsWindow.getBounds();
        this.settingsWindowHelper.showWindow(x, y, { activate });
      }
    }

    if (session.wasModelSelectorVisible) {
      const modelSelectorWindow = this.modelSelectorWindowHelper.getWindow();
      if (modelSelectorWindow && !modelSelectorWindow.isDestroyed()) {
        const { x, y } = modelSelectorWindow.getBounds();
        this.modelSelectorWindowHelper.showWindow(x, y, { activate });
      }
    }
  }

  private async withScreenshotCaptureSession<T>(
    captureKind: ScreenshotCaptureKind,
    restoreFocus: boolean,
    capture: (session: ScreenshotCaptureSession) => Promise<T>
  ): Promise<T> {
    if (!this.getMainWindow()) {
      throw new Error("No main window available");
    }

    if (this.screenshotCaptureInProgress) {
      throw new Error("Screenshot capture already in progress");
    }

    const session = this.createScreenshotCaptureSession(captureKind, restoreFocus);
    this.screenshotCaptureInProgress = true;

    try {
      this.hideWindowsForScreenshot(session);
      await new Promise(resolve => setTimeout(resolve, 50));
      return await capture(session);
    } finally {
      try {
        this.restoreWindowsAfterScreenshot(session);
      } finally {
        this.screenshotCaptureInProgress = false;
      }
    }
  }

  // Screenshot management methods
  public async takeScreenshot(restoreFocus: boolean = true): Promise<string> {
    return this.withScreenshotCaptureSession('full', restoreFocus, (session) =>
      this.screenshotHelper.takeScreenshot(this.getTargetDisplayForFullScreenshot(session))
    )
  }

  public async takeSelectiveScreenshot(restoreFocus: boolean = true): Promise<string> {
    return this.withScreenshotCaptureSession('selective', restoreFocus, async () => {
      let captureArea: Electron.Rectangle | undefined;

      if (process.platform === 'win32' || process.platform === 'darwin') {
        captureArea = await this.cropperWindowHelper.showCropper();

        if (!captureArea) {
          throw new Error("Selection cancelled");
        }
      }

      return this.screenshotHelper.takeSelectiveScreenshot(captureArea)
    })
  }

  public async getImagePreview(filepath: string): Promise<string> {
    return this.screenshotHelper.getImagePreview(filepath)
  }

  public async deleteScreenshot(
    path: string
  ): Promise<{ success: boolean; error?: string }> {
    return this.screenshotHelper.deleteScreenshot(path)
  }

  // New methods to move the window
  public moveWindowLeft(): void {
    this.windowHelper.moveWindowLeft()
  }

  public moveWindowRight(): void {
    this.windowHelper.moveWindowRight()
  }
  public moveWindowDown(): void {
    this.windowHelper.moveWindowDown()
  }
  public moveWindowUp(): void {
    this.windowHelper.moveWindowUp()
  }

  public centerAndShowWindow(): void {
    this.windowHelper.centerAndShowWindow()
  }

  public createTray(): void {
    this.showTray();
  }

  public showTray(): void {
    if (this.tray) return;

    // Try to find a template image first for macOS
    const resourcesPath = app.isPackaged ? process.resourcesPath : app.getAppPath();

    // Potential paths for tray icon
    const templatePath = path.join(resourcesPath, 'assets', 'iconTemplate.png');
    const defaultIconPath = app.isPackaged
      ? path.join(resourcesPath, 'src/components/icon.png')
      : path.join(app.getAppPath(), 'src/components/icon.png');

    let iconToUse = defaultIconPath;

    // Check if template exists (sync check is fine for startup/rare toggle)
    try {
      if (require('fs').existsSync(templatePath)) {
        iconToUse = templatePath;
        console.log('[Tray] Using template icon:', templatePath);
      } else {
        // Also check src/components for dev
        const devTemplatePath = path.join(app.getAppPath(), 'src/components/iconTemplate.png');
        if (require('fs').existsSync(devTemplatePath)) {
          iconToUse = devTemplatePath;
          console.log('[Tray] Using dev template icon:', devTemplatePath);
        } else {
          console.log('[Tray] Template icon not found, using default:', defaultIconPath);
        }
      }
    } catch (e) {
      console.error('[Tray] Error checking for icon:', e);
    }

    const trayIcon = nativeImage.createFromPath(iconToUse).resize({ width: 16, height: 16 });
    // IMPORTANT: specific template settings for macOS if needed, but 'Template' in name usually suffices
    trayIcon.setTemplateImage(iconToUse.endsWith('Template.png'));

    this.tray = new Tray(trayIcon)
    this.tray.setToolTip('Godojo.ai') // This tooltip might also need update if we change global shortcut, but global shortcut is removed.
    this.updateTrayMenu();

    // Double-click to show window
    this.tray.on('double-click', () => {
      this.centerAndShowWindow()
    })
  }

  public updateTrayMenu() {
    if (!this.tray) return;

    // ── NEW: capture live state ──
    const isActive = this.isMeetingActive;
    const isPaused = this.isMeetingPaused;

    const keybindManager = KeybindManager.getInstance();
    const screenshotAccel = keybindManager.getKeybind('general:take-screenshot') || 'CommandOrControl+H';

    console.log('[Main] updateTrayMenu called. Screenshot Accelerator:', screenshotAccel);

    // Update tooltip for verification
    this.tray.setToolTip('Godojo.ai');

    // Helper to format accelerator for display (e.g. CommandOrControl+H -> Cmd+H)
    const formatAccel = (accel: string) => {
      return accel
        .replace('CommandOrControl', 'Cmd')
        .replace('Command', 'Cmd')
        .replace('Control', 'Ctrl')
        .replace('OrControl', '') // Cleanup just in case
        .replace(/\+/g, '+');
    };

    const displayScreenshot = formatAccel(screenshotAccel);
    // We can also get the toggle visibility shortcut if desired
    const toggleKb = keybindManager.getKeybind('general:toggle-visibility');
    const toggleAccel = toggleKb || 'CommandOrControl+B';
    const displayToggle = formatAccel(toggleAccel);

    const contextMenu = Menu.buildFromTemplate([
      // ── NEW: pause status indicator (only shown during an active meeting) ──
      ...(isActive ? [{
        label: isPaused ? '⏸  Meeting Paused' : '🔴  Meeting Active',
        enabled: false,   // non-clickable status label
      }, {
        type: 'separator' as const,
      }] : []),
      {
        label: 'Show Godojo.ai',
        click: () => {
          this.centerAndShowWindow()
        }
      },
      {
        label: `Toggle Window (${displayToggle})`,
        click: () => {
          this.toggleMainWindow()
        }
      },
      {
        type: 'separator'
      },
      {
        label: `Take Screenshot (${displayScreenshot})`,
        accelerator: screenshotAccel,
        click: async () => {
          try {
            const screenshotPath = await this.takeScreenshot()
            const preview = await this.getImagePreview(screenshotPath)
            const mainWindow = this.getMainWindow()
            if (mainWindow) {
              mainWindow.webContents.send("screenshot-taken", {
                path: screenshotPath,
                preview
              })
            }
          } catch (error) {
            console.error("Error taking screenshot from tray:", error)
          }
        }
      },
      {
        type: 'separator'
      },
      {
        label: 'Quit',
        accelerator: 'Command+Q',
        click: () => {
          app.quit()
        }
      }
    ])

    this.tray.setContextMenu(contextMenu)
  }

  public hideTray(): void {
    if (this.tray) {
      this.tray.destroy();
      this.tray = null;
    }
  }

  public setHasDebugged(value: boolean): void {
    this.hasDebugged = value
  }

  public getHasDebugged(): boolean {
    return this.hasDebugged
  }

  public setUndetectable(state: boolean): void {
    // Guard: skip if state hasn't actually changed to prevent
    // duplicate dock hide/show cycles from renderer feedback loops
    if (this.isUndetectable === state) return;

    console.log(`[Stealth] setUndetectable(${state}) called`);

    this.isUndetectable = state
    this.windowHelper.setContentProtection(state)
    this.settingsWindowHelper.setContentProtection(state)
    this.modelSelectorWindowHelper.setContentProtection(state)
    this.cropperWindowHelper.setContentProtection(state)

    // Persist state via SettingsManager
    SettingsManager.getInstance().set('isUndetectable', state);

    // Cancel all pending disguise timers to prevent their app.setName() calls
    // from re-registering the dock icon after we hide it
    if (state) {
      for (const timer of this._disguiseTimers) {
        clearTimeout(timer);
      }
      this._disguiseTimers = [];
    }

    // Broadcast state change to all relevant windows
    this._broadcastToAllWindows('undetectable-changed', state);

    // --- STEALTH MODE LOGIC ---
    // The dock hide/show is debounced: rapid toggles update isUndetectable immediately
    // (so content protection, IPC broadcasts and the guard above are always current),
    // but the actual macOS dock/tray/focus operation only fires once the user stops
    // toggling. This eliminates the race where dock.show() + NSApp.activate() lingers
    // after a subsequent dock.hide() call.
    if (process.platform === 'darwin') {
      if (this._dockDebounceTimer) {
        clearTimeout(this._dockDebounceTimer);
        this._dockDebounceTimer = null;
      }

      this._dockDebounceTimer = setTimeout(() => {
        this._dockDebounceTimer = null;

        // Read the settled state — may differ from the `state` captured above
        // if the user toggled again before the timer fired.
        const settled = this.isUndetectable;

        const activeWindow = this.windowHelper.getMainWindow();
        const settingsWindow = this.settingsWindowHelper.getSettingsWindow();
        let targetFocusWindow = activeWindow;
        if (settingsWindow && !settingsWindow.isDestroyed() && settingsWindow.isVisible()) {
          targetFocusWindow = settingsWindow;
        }

        const modelSelectorWindow = this.modelSelectorWindowHelper.getWindow();
        const isModelSelectorVisible = modelSelectorWindow && !modelSelectorWindow.isDestroyed() && modelSelectorWindow.isVisible();

        if (targetFocusWindow && targetFocusWindow === settingsWindow) {
          this.settingsWindowHelper.setIgnoreBlur(true);
        }
        if (isModelSelectorVisible) {
          this.modelSelectorWindowHelper.setIgnoreBlur(true);
        }

        if (settled) {
          // Capture whether Natively is currently the frontmost app BEFORE
          // dock.hide() — that call triggers an implicit macOS app-deactivation
          // which shifts keyboard focus to the next frontmost app (Chrome, etc.).
          const nativelyWasFocused =
            targetFocusWindow != null &&
            !targetFocusWindow.isDestroyed() &&
            targetFocusWindow.isFocused();

          console.log('[Stealth] Calling app.dock.hide()');
          app.dock.hide();
          this.hideTray();

          // If Natively was the focused window when the user toggled stealth,
          // restore focus to our window after dock.hide() so macOS does not
          // hand control to Chrome / whatever is behind us.
          // We use win.focus() (not app.focus()) to avoid the heavy-handed
          // [NSApp activateIgnoringOtherApps:YES] side-effect.
          if (nativelyWasFocused && targetFocusWindow && !targetFocusWindow.isDestroyed()) {
            targetFocusWindow.focus();
          }
        } else {
          console.log('[Stealth] Calling app.dock.show()');
          app.dock.show();
          this.showTray();
          // Do NOT call focus() — let the user's current app retain focus
        }

        if (targetFocusWindow && targetFocusWindow === settingsWindow) {
          setTimeout(() => { this.settingsWindowHelper.setIgnoreBlur(false); }, 500);
        }
        if (isModelSelectorVisible) {
          setTimeout(() => { this.modelSelectorWindowHelper.setIgnoreBlur(false); }, 500);
        }
      }, 150);
    }
  }

  public getUndetectable(): boolean {
    return this.isUndetectable
  }

  // --- Mouse Passthrough (Adapted from public PR #113 — verify premium interaction) ---
  private overlayMousePassthrough: boolean = false;

  public setOverlayMousePassthrough(state: boolean): void {
    if (this.overlayMousePassthrough === state) return;

    console.log(`[Overlay] setOverlayMousePassthrough(${state}) called`);

    this.overlayMousePassthrough = state;
    this.windowHelper.syncOverlayInteractionPolicy();
    this._broadcastToAllWindows('overlay-mouse-passthrough-changed', state);
  }

  public toggleOverlayMousePassthrough(): boolean {
    const next = !this.overlayMousePassthrough;
    this.setOverlayMousePassthrough(next);
    return next;
  }

  public getOverlayMousePassthrough(): boolean {
    return this.overlayMousePassthrough;
  }

  public getVerboseLogging(): boolean {
    return this._verboseLogging;
  }

  public setVerboseLogging(enabled: boolean): void {
    this._verboseLogging = enabled;
    setVerboseLoggingFlag(enabled);
    SettingsManager.getInstance().set('verboseLogging', enabled);
    console.log(`[AppState] verboseLogging set to ${enabled}`);
  }

  public setDisguise(mode: 'terminal' | 'settings' | 'activity' | 'none'): void {
    this.disguiseMode = mode;
    SettingsManager.getInstance().set('disguiseMode', mode);

    // Apply the disguise regardless of undetectable state
    // (disguise affects Activity Monitor name via process.title,
    //  dock icon only updates when NOT in stealth)
    this._applyDisguise(mode);
  }

  public applyInitialDisguise(): void {
    this._applyDisguise(this.disguiseMode);
  }

  private _applyDisguise(mode: 'terminal' | 'settings' | 'activity' | 'none'): void {
    let appName = "Godojo.ai";
    let iconPath = "";

    const isWin = process.platform === 'win32';
    const isMac = process.platform === 'darwin';

    switch (mode) {
      case 'terminal':
        appName = isWin ? "Command Prompt " : "Terminal ";
        if (isWin) {
          iconPath = app.isPackaged
            ? path.join(process.resourcesPath, "assets/fakeicon/win/terminal.png")
            : path.join(app.getAppPath(), "assets/fakeicon/win/terminal.png");
        } else {
          iconPath = app.isPackaged
            ? path.join(process.resourcesPath, "assets/fakeicon/mac/terminal.png")
            : path.join(app.getAppPath(), "assets/fakeicon/mac/terminal.png");
        }
        break;
      case 'settings':
        appName = isWin ? "Settings " : "System Settings ";
        if (isWin) {
          iconPath = app.isPackaged
            ? path.join(process.resourcesPath, "assets/fakeicon/win/settings.png")
            : path.join(app.getAppPath(), "assets/fakeicon/win/settings.png");
        } else {
          iconPath = app.isPackaged
            ? path.join(process.resourcesPath, "assets/fakeicon/mac/settings.png")
            : path.join(app.getAppPath(), "assets/fakeicon/mac/settings.png");
        }
        break;
      case 'activity':
        appName = isWin ? "Task Manager " : "Activity Monitor ";
        if (isWin) {
          iconPath = app.isPackaged
            ? path.join(process.resourcesPath, "assets/fakeicon/win/activity.png")
            : path.join(app.getAppPath(), "assets/fakeicon/win/activity.png");
        } else {
          iconPath = app.isPackaged
            ? path.join(process.resourcesPath, "assets/fakeicon/mac/activity.png")
            : path.join(app.getAppPath(), "assets/fakeicon/mac/activity.png");
        }
        break;
      case 'none':
        appName = "Godojo.ai";
        if (isMac) {
          iconPath = app.isPackaged
            ? path.join(process.resourcesPath, "natively.icns")
            : path.join(app.getAppPath(), "assets/natively.icns");
        } else if (isWin) {
          iconPath = app.isPackaged
            ? path.join(process.resourcesPath, "assets/icons/win/icon.ico")
            : path.join(app.getAppPath(), "assets/icons/win/icon.ico");
        } else {
          iconPath = app.isPackaged
            ? path.join(process.resourcesPath, "icon.png")
            : path.join(app.getAppPath(), "assets/icon.png");
        }
        break;
    }

    console.log(`[AppState] Applying disguise: ${mode} (${appName}) on ${process.platform}`);

    // 1. Update process title (affects Activity Monitor / Task Manager)
    process.title = appName;

    // 2. Update app name (affects macOS Menu / Dock)
    // Skip when undetectable — app.setName() causes macOS to re-register
    // the app and re-show the dock icon even after dock.hide()
    if (!this.isUndetectable) {
      app.setName(appName);
    }

    if (isMac) {
      process.env.CFBundleName = appName.trim();
    }

    // 3. Update App User Model ID (Windows Taskbar grouping)
    if (isWin) {
      // Use unique AUMID per disguise to avoid grouping with the real app
      app.setAppUserModelId(`com.natively.assistant.${mode}`);
    }

    // 4. Update Icons
    if (fs.existsSync(iconPath)) {
      const image = nativeImage.createFromPath(iconPath);

      if (isMac) {
        // Skip dock icon update when dock is hidden to avoid potential flicker
        if (!this.isUndetectable) {
          app.dock.setIcon(image);
        }
      } else {
        // Windows/Linux: Update all window icons
        this.windowHelper.getLauncherWindow()?.setIcon(image);
        this.windowHelper.getOverlayWindow()?.setIcon(image);
        this.settingsWindowHelper.getSettingsWindow()?.setIcon(image);
      }
    } else {
      console.warn(`[AppState] Disguise icon not found: ${iconPath}`);
    }

    // 5. Update Window Titles
    const launcher = this.windowHelper.getLauncherWindow();
    if (launcher && !launcher.isDestroyed()) {
      launcher.setTitle(appName.trim());
      launcher.webContents.send('disguise-changed', mode);
    }

    const overlay = this.windowHelper.getOverlayWindow();
    if (overlay && !overlay.isDestroyed()) {
      overlay.setTitle(appName.trim());
      overlay.webContents.send('disguise-changed', mode);
    }

    const settingsWin = this.settingsWindowHelper.getSettingsWindow();
    if (settingsWin && !settingsWin.isDestroyed()) {
      settingsWin.setTitle(appName.trim());
      settingsWin.webContents.send('disguise-changed', mode);
    }

    // Cancel any stale forceUpdate timeouts from previous disguise changes
    for (const timer of this._disguiseTimers) {
      clearTimeout(timer);
    }
    this._disguiseTimers = [];

    // Periodically re-assert process.title only — it can drift on some systems.
    // NOTE: We intentionally do NOT call app.setName() here — it was already called
    // synchronously above, and repeated calls on macOS cause the system to briefly
    // show a second dock tile while re-registering the app identity.
    const scheduleUpdate = (ms: number) => {
      const ts = setTimeout(() => {
        process.title = appName;
        this._disguiseTimers = this._disguiseTimers.filter(t => t !== ts);
      }, ms);
      this._disguiseTimers.push(ts);
    };

    scheduleUpdate(200);
    scheduleUpdate(1000);
    scheduleUpdate(5000);
  }

  // Helper: broadcast an IPC event to all windows
  private _broadcastToAllWindows(channel: string, ...args: any[]): void {
    const windows = [
      this.windowHelper.getMainWindow(),
      this.windowHelper.getLauncherWindow(),
      this.windowHelper.getOverlayWindow(),
      this.settingsWindowHelper.getSettingsWindow(),
      this.modelSelectorWindowHelper.getWindow(),
    ];
    const sent = new Set<number>();
    for (const win of windows) {
      if (win && !win.isDestroyed() && !sent.has(win.id)) {
        sent.add(win.id);
        win.webContents.send(channel, ...args);
      }
    }
  }

  public getDisguise(): string {
    return this.disguiseMode;
  }
}

// Application initialization

async function initializeApp() {
  // 1. Enforce single instance — prevent duplicate dock icons from leftover processes.
  // In development mode with hot-reload this is still safe because electron is restarted
  // by the build step, not re-launched by concurrently while the old process is alive.
  const gotLock = app.requestSingleInstanceLock();
  if (!gotLock) {
    console.log('[Main] Another instance is already running. Quitting this instance.');
    app.quit();
    return;
  }

  // Windows/Linux deliver the deep link as an argv entry to the already-
  // running instance via 'second-instance' (macOS uses 'open-url' above).
  // This also covers the ordinary "user double-clicked the app again while
  // it's already open" case, so we still focus/restore the window even
  // when no deep link is present.
  app.on('second-instance', (_event, argv) => {
    const deepLinkArg = argv.find(
      (a) => a.startsWith(`${INVITE_PROTOCOL}://`) || a.includes('/invite?token=')
    );
    if (deepLinkArg) {
      handleInviteDeepLink(deepLinkArg);
    } else {
      const appState = AppState.getInstance();
      const win = appState.getMainWindow();
      if (win) {
        if (!appState.isVisible()) appState.toggleMainWindow();
        win.focus();
      }
    }
  });

  // Register this app as the OS handler for godojo:// links.
  if (process.defaultApp) {
    if (process.argv.length >= 2) {
      app.setAsDefaultProtocolClient(INVITE_PROTOCOL, process.execPath, [
        path.resolve(process.argv[1]),
      ]);
    }
  } else {
    app.setAsDefaultProtocolClient(INVITE_PROTOCOL);
  }

  // Cold start on Windows/Linux: the OS launches a fresh process with the
  // deep link URL as an argv entry instead of firing 'second-instance'.
  // macOS cold starts are handled by the 'open-url' listener registered at
  // module load time above.
  const coldStartDeepLinkArg = process.argv.find(
    (a) => a.startsWith(`${INVITE_PROTOCOL}://`) || a.includes('/invite?token=')
  );
  if (coldStartDeepLinkArg) {
    const token = extractInviteToken(coldStartDeepLinkArg);
    if (token) pendingInviteToken = token;
  }

  // 2. Wait for app to be ready
  await app.whenReady()

  // 2a. PRE-EMPTIVE dock hide: must happen before ANY operation that causes macOS to
  // register a dock entry (app.setName, BrowserWindow creation, etc.).
  // We read isUndetectable directly from settings here — AppState singleton isn't
  // constructed yet, so we cannot call appState.getUndetectable().
  if (process.platform === 'darwin') {
    // SettingsManager is already statically imported — no require() needed.
    const isUndetectableOnStartup = SettingsManager.getInstance().get('isUndetectable') ?? false;
    if (isUndetectableOnStartup) {
      app.dock.hide();
    }
  }

  // 3. Initialize Managers
  // Initialize CredentialsManager and load keys explicitly
  // This fixes the issue where keys (especially in production) aren't loaded in time for RAG/LLM
  const { CredentialsManager } = require('./services/CredentialsManager');
  CredentialsManager.getInstance().init();

  // 3a. Initialize cloud sync stack: Firebase Auth identity restore + Supabase client.
  //     The renderer's trySilentRestore() owns the actual refresh-token exchange
  //     (it has the Firebase Web SDK + project apiKey). Main-side we just:
  //       a. SupabaseClientManager.init() picks up persisted project URL/anon key
  //          and constructs the supabase-js client with the accessToken callback.
  //       b. SupabaseMirrorService.getInstance().init(db) below — done after
  //          DatabaseManager is up — wires the outbox table and starts listening
  //          for AuthManager 'signed-in' / 'auth-changed' events.

  // Dev convenience: in unpackaged builds, if SUPABASE_URL / SUPABASE_KEY are present
  // in the loaded .env AND no credentials have been persisted yet, hydrate them once
  // so the SQL DDL / mirror flow works without manually calling supabaseSetCredentials
  // from DevTools on every fresh machine. No-op in production builds.
  try {
    if (!app.isPackaged && process.env.SUPABASE_URL && process.env.SUPABASE_KEY) {
      const cm = CredentialsManager.getInstance();
      const existing = cm.getSupabaseCredentials?.();
      if (!existing?.url || !existing?.anonKey) {
        cm.setSupabaseCredentials(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
        console.log('[Main] Supabase credentials hydrated from .env (dev only)');
      }
    }
  } catch (e) {
    console.warn('[Main] Supabase .env hydration failed (non-fatal):', e);
  }

  try {
    const { SupabaseClientManager } = require('./db/SupabaseClient');
    SupabaseClientManager.init();
  } catch (e) {
    console.warn('[Main] SupabaseClientManager.init failed (non-fatal):', e);
  }
  try {
    const { SupabaseMirrorService } = require('./db/SupabaseMirrorService');
    const { DatabaseManager } = require('./db/DatabaseManager');
    const sqliteDb = DatabaseManager.getInstance().getDb();
    if (sqliteDb) {
      SupabaseMirrorService.getInstance().init(sqliteDb);
      console.log('[Main] SupabaseMirrorService initialized');

      // One-time historical backfill: pushes any local SQLite rows that pre-date
      // mirror configuration up to Supabase. Idempotent — the backfill module
      // checkpoints progress in app_state ('supabase_backfill_done') so it's a
      // no-op after the first successful run. Must wait for a Firebase session
      // because every upsert is RLS-scoped on auth.jwt() -> 'sub'.
      try {
        const { SupabaseBackfill } = require('./db/SupabaseBackfill');
        const { AuthManager } = require('./services/AuthManager');
        const auth = AuthManager.getInstance();

        const runBackfillOnce = () => {
          // Fire-and-forget; SupabaseBackfill.run handles its own errors and
          // re-checkpoints, so a transient failure just means we'll resume on
          // the next launch.
          SupabaseBackfill.run(sqliteDb).catch((err: any) => {
            console.warn('[Main] SupabaseBackfill.run failed (non-fatal):', err);
          });
        };

        if (auth.isSignedIn()) {
          runBackfillOnce();
        } else {
          // Wait for the renderer's silent-restore / first sign-in to deliver
          // an ID token, then run exactly once.
          auth.once('signed-in', runBackfillOnce);
        }
      } catch (e) {
        console.warn('[Main] SupabaseBackfill wiring failed (non-fatal):', e);
      }

      // Gap detection: compare local SQLite IDs against Supabase and re-queue
      // any rows that never made it (silent outbox failures, pre-credentials
      // writes, etc.). Runs concurrently with the backfill; fire-and-forget.
      try {
        const { SupabaseSyncAudit } = require('./db/SupabaseSyncAudit');
        const { AuthManager } = require('./services/AuthManager');
        const auth = AuthManager.getInstance();

        const runAuditOnce = () => {
          SupabaseSyncAudit.run(sqliteDb).catch((err: any) => {
            console.warn('[Main] SupabaseSyncAudit.run failed (non-fatal):', err);
          });
        };

        if (auth.isSignedIn()) {
          runAuditOnce();
        } else {
          auth.once('signed-in', runAuditOnce);
        }
      } catch (e) {
        console.warn('[Main] SupabaseSyncAudit wiring failed (non-fatal):', e);
      }
    } else {
      console.warn('[Main] DatabaseManager has no DB handle yet — mirror service deferred');
    }
  } catch (e) {
    console.warn('[Main] SupabaseMirrorService init failed (non-fatal):', e);
  }

  // 4. Initialize State
  const appState = AppState.getInstance()

  // Explicitly load credentials into helpers
  appState.processingHelper.loadStoredCredentials();

  // Initialize IPC handlers before window creation
  initializeIpcHandlers(appState)

  // Apply the full disguise payload (names, dock icon, AUMID) early
  appState.applyInitialDisguise();

  // Start the Ollama lifecycle manager
  OllamaManager.getInstance().init().catch(console.error);

  // NOTE: CredentialsManager.init() and loadStoredCredentials() are already called
  // above before this block — do NOT call them again here to avoid double key-load.

  // Anonymous install ping - one-time, non-blocking
  // See electron/services/InstallPingManager.ts for privacy details
  const { sendAnonymousInstallPing } = require('./services/InstallPingManager');
  sendAnonymousInstallPing();

  // Load stored Google Service Account path (for Speech-to-Text)
  const storedServiceAccountPath = CredentialsManager.getInstance().getGoogleServiceAccountPath();
  if (storedServiceAccountPath) {
    console.log("[Init] Loading stored Google Service Account path");
    appState.updateGoogleCredentials(storedServiceAccountPath);
  }

  console.log("App is ready")

  await initRendererUrl()

  appState.createWindow()

  // If a deep link arrived before the window existed (cold start), deliver
  // it now that the renderer is up and listening.
  const mainWindowForDeepLink = appState.getMainWindow();
  if (mainWindowForDeepLink) {
    mainWindowForDeepLink.webContents.once('did-finish-load', () => {
      if (pendingInviteToken) {
        mainWindowForDeepLink.webContents.send('invite-deep-link', { token: pendingInviteToken });
        pendingInviteToken = null;
      }
    });
  }

  // Apply initial stealth state based on isUndetectable setting.
  // NOTE: app.dock.hide() was already called pre-emptively before createWindow()
  // when isUndetectable=true. Here we only need to initialize the tray for non-stealth mode.
  if (!appState.getUndetectable()) {
    // Normal mode: show tray (dock is already showing — no need to call dock.show() again)
    appState.showTray();
  }
  // Stealth mode: dock is already hidden, tray stays hidden, no action needed here.
  // Register global shortcuts using KeybindManager
  KeybindManager.getInstance().registerGlobalShortcuts()

  // Pre-create settings window in background for faster first open
  appState.settingsWindowHelper.preloadWindow()

  // Initialize CalendarManager
  try {
    const { CalendarManager } = require('./services/CalendarManager');
    const calMgr = CalendarManager.getInstance();
    calMgr.init();

    calMgr.on('start-meeting-requested', (event: any) => {
      console.log('[Main] Start meeting requested from calendar notification', event);
      appState.centerAndShowWindow();
      appState.startMeeting({
        title: event.title,
        calendarEventId: event.id,
        source: 'calendar',
        attendees: event.attendees || [],
        organizer: event.organizer || '',
      });
    });

    calMgr.on('open-requested', () => {
      appState.centerAndShowWindow();
    });

    console.log('[Main] CalendarManager initialized');
  } catch (e) {
    console.error('[Main] Failed to initialize CalendarManager:', e);
  }

  // Initialize Zoom Calendar Manager
  try {
    const { ZoomCalendarManager } = require('./services/ZoomCalendarManager');
    const zoomCal = ZoomCalendarManager.getInstance();
    zoomCal.init();
    console.log('[Main] ZoomCalendarManager initialized');
  } catch (e) {
    console.error('[Main] Failed to initialize ZoomCalendarManager:', e);
  }

  // Recover unprocessed meetings (persistence check)
  appState.getIntelligenceManager().recoverUnprocessedMeetings().catch(err => {
    console.error('[Main] Failed to recover unprocessed meetings:', err);
  });

  // Note: We do NOT force dock show here anymore, respecting stealth mode.

  app.on("activate", () => {
    console.log("App activated")
    if (process.platform === 'darwin') {
      // Do NOT call dock.show() while a meeting is running — the dock icon
      // appearing mid-meeting is a critical stealth failure.
      if (!appState.getUndetectable() && !appState.getIsMeetingActive()) {
        app.dock.show();
      }
    }

    // If no window exists, create it
    if (appState.getMainWindow() === null) {
      appState.createWindow()
    } else {
      // If the window exists but is hidden, clicking the dock icon should restore it
      if (!appState.isVisible()) {
        appState.toggleMainWindow();
      }
    }
  })

  // Quit when all windows are closed, except on macOS
  app.on("window-all-closed", () => {
    if (process.platform !== "darwin") {
      app.quit()
    }
  })

  // Scrub API keys from memory on quit to minimize exposure window
  app.on("before-quit", (event) => {
    console.log("App is quitting, cleaning up resources...");
    appState.setQuitting(true);

    // Dispose CropperWindowHelper to clean up IPC listeners and prevent memory leaks
    // This is critical to prevent resource leaks and ensure proper cleanup
    if (appState?.cropperWindowHelper) {
      appState.cropperWindowHelper.dispose();
    }

    // Kill Ollama if we started it
    OllamaManager.getInstance().stop();

    try {
      const { CredentialsManager } = require('./services/CredentialsManager');
      CredentialsManager.getInstance().scrubMemory();
      appState.processingHelper.getLLMHelper().scrubKeys();
      console.log('[Main] Credentials scrubbed from memory on quit');
    } catch (e) {
      console.error('[Main] Failed to scrub credentials on quit:', e);
    }
  })



  // app.dock?.hide() // REMOVED: User wants Dock icon visible
  app.commandLine.appendSwitch("disable-background-timer-throttling")
}

// Start the application
initializeApp().catch(console.error)