import { ChevronUp, ChevronDown, PointerOff, Play, Pause } from "lucide-react";
import icon from "../icon.png";
import type { OverlayAppearance } from "../../lib/overlayAppearance";

interface TopPillProps {
    expanded: boolean;
    onToggle: () => void;
    onQuit: () => void;
    onPause: () => void;
    isPaused: boolean;
    appearance: OverlayAppearance;
    onLogoClick?: () => void;
}

export default function TopPill({
    expanded,
    onToggle,
    onQuit,
    onPause,
    isPaused,
    appearance,
    onLogoClick,
}: TopPillProps) {
    return (
        <div className="flex justify-center mt-2 select-none z-50">
            <div
                className="
                    draggable-area
                    flex items-center gap-2
                    rounded-full
                    overlay-pill-surface
                    backdrop-blur-md
                    pl-1.5 pr-1.5 py-1.5
                    transition-all duration-300 ease-sculpted
                "
                style={appearance.pillStyle}
            >
                {/* LOGO BUTTON */}
                <button
                    onClick={onLogoClick}
                    className={`
                        w-8 h-8
                        rounded-full
                        overlay-icon-surface
                        overlay-icon-surface-hover
                        flex items-center justify-center
                        relative overflow-hidden
                        interaction-base interaction-press
                    `}
                    style={appearance.iconStyle}
                >
                    <img
                        src={icon}
                        alt="Natively"
                        className="w-[24px] h-[24px] object-contain opacity-95 scale-105 force-black-icon"
                        draggable="false"
                        onDragStart={(e) => e.preventDefault()}
                    />
                </button>

                {/* CENTER SEGMENT */}
                <button
                    onClick={onToggle}
                    className={`
                        flex items-center gap-2
                        group
                        px-4 py-1.5
                        rounded-full
                        backdrop-blur-md
                        overlay-chip-surface
                        overlay-text-interactive
                        text-[12px]
                        font-medium
                        border
                        interaction-base interaction-hover interaction-press
                    `}
                    style={appearance.chipStyle}
                >
                    <span className="opacity-70 group-hover:opacity-100 transition-opacity duration-200">
                        {expanded ? (
                            <ChevronUp className="w-3.5 h-3.5" />
                        ) : (
                            <ChevronDown className="w-3.5 h-3.5" />
                        )}
                    </span>
                    <span className="tracking-wide opacity-80 group-hover:opacity-100">{expanded ? "Hide" : "Show"}</span>
                </button>

                {/* PAUSE / RESUME BUTTON — NEW */}
                <button
                    onClick={onPause}
                    title={isPaused ? "Resume meeting" : "Pause meeting"}
                    className={`
                        w-8 h-8
                        rounded-full
                        overlay-icon-surface
                        flex items-center justify-center
                        interaction-base interaction-press
                        transition-all duration-200
                        ${isPaused
                            ? 'text-amber-400 bg-amber-500/10 hover:bg-amber-500/20'
                            : 'overlay-text-primary hover:bg-amber-500/10 hover:text-amber-400'
                        }
                    `}
                    style={appearance.iconStyle}
                >
                    {isPaused
                        ? <Play className="w-3.5 h-3.5" />
                        : <Pause className="w-3.5 h-3.5" />
                    }
                </button>

                {/* STOP / QUIT BUTTON */}
                <button
                    onClick={onQuit}
                    className={`
                        w-8 h-8
                        rounded-full
                        overlay-icon-surface
                        overlay-text-primary
                        flex items-center justify-center
                        interaction-base interaction-press
                        hover:bg-red-500/10 hover:text-red-400
                    `}
                    style={appearance.iconStyle}
                >
                    <div className="w-3.5 h-3.5 rounded-[3px] bg-current opacity-80" />
                </button>
            </div>
        </div>
    );
}
