import React from 'react';
import { Trash2, AlertCircle, CheckCircle, ExternalLink, Loader2, RefreshCw } from 'lucide-react';
import { useResolvedTheme, useProviderCard } from '@/hooks';
import { ProviderCardProps } from '@/types';
import ModelDropdown from './ModelDropdown';

// ============================================
// Main Component
// ============================================
// A single AI-provider settings card: API key input/save/remove, connection
// test, and (once a key is stored) model discovery + selection. All state,
// the auto-save timer, and model-fetch logic now live in useProviderCard —
// this component only renders.
export const ProviderCard: React.FC<ProviderCardProps> = ({
    providerId,
    providerName,
    apiKey,
    preferredModel,
    hasStoredKey,
    onKeyChange,
    onSaveKey,
    onRemoveKey,
    onTestConnection,
    testStatus,
    testError,
    savingStatus,
    savedStatus,
    keyPlaceholder,
    keyUrl,
    onPreferredModelChange,
}) => {
    const isLight = useResolvedTheme() === 'light';

    const {
        fetchedModels,
        isFetching,
        fetchError,
        selectedModel,
        selectedOption,
        isDropdownOpen,
        dropdownRef,
        handleFetchModels,
        handleSelectModel,
        toggleDropdown,
    } = useProviderCard({
        providerId,
        apiKey,
        preferredModel,
        hasStoredKey,
        onSaveKey,
        onPreferredModelChange,
        savedStatus,
        savingStatus,
    });

    return (
        <div className="bg-bg-item-surface rounded-xl p-5 border border-border-subtle">
            <div className="mb-2 flex items-center justify-between">
                <label className="flex items-center text-xs font-medium text-text-primary uppercase tracking-wide">
                    {providerName} API Key
                    {hasStoredKey && <span className="ml-2 text-green-500 normal-case">✓ Saved</span>}
                </label>
                <button
                    onClick={() => {
                        // @ts-ignore
                        window.electronAPI?.openExternal(keyUrl);
                    }}
                    className="text-xs text-text-tertiary hover:text-text-primary flex items-center gap-1 transition-colors"
                    title={`Get ${providerName} API Key`}
                >
                    <span className="text-[10px] uppercase tracking-wide">Get Key</span>
                    <ExternalLink size={12} />
                </button>
            </div>
            <div className="flex gap-2 mb-3">
                <input
                    type="password"
                    value={apiKey}
                    onChange={(e) => onKeyChange(e.target.value)}
                    placeholder={hasStoredKey ? "••••••••••••" : keyPlaceholder}
                    className={`flex-1 ${isLight ? "bg-bg-input" : "bg-gray-900"} border border-border-subtle rounded-lg px-4 py-2.5 text-xs text-text-primary focus:outline-none focus:border-accent-primary transition-colors`}
                />
                <button
                    onClick={onSaveKey}
                    disabled={savingStatus || !apiKey.trim()}
                    className={`px-5 py-2.5 rounded-lg text-xs font-medium transition-colors ${savedStatus
                        ? 'bg-green-500/20 text-green-400'
                        : `bg-bg-input ${savingStatus || !apiKey.trim() ? "" : "bg-bg-elevated"} border border-border-subtle text-text-primary disabled:cursor-not-allowed disabled:opacity-50`
                        }`}
                >
                    {savingStatus ? 'Saving...' : savedStatus ? 'Saved!' : 'Save'}
                </button>
                {hasStoredKey && (
                    <button
                        onClick={onRemoveKey}
                        className="px-2.5 py-2.5 rounded-lg text-xs font-medium text-text-tertiary hover:text-red-500 hover:bg-red-500/10 transition-all"
                        title="Remove API Key"
                    >
                        <Trash2 size={16} strokeWidth={1.5} />
                    </button>
                )}
            </div>

            {/* Action Row: Test Connection + Conditional Dropdown + Fetch Models */}
            <div className="flex items-center justify-between mb-3 w-full">
                <button
                    onClick={onTestConnection}
                    disabled={(!apiKey.trim() && !hasStoredKey) || testStatus === 'testing'}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors border border-border-subtle flex items-center gap-2 shrink-0 ${testStatus === 'success' ? 'bg-green-500/10 text-green-500 border-green-500/20' :
                        testStatus === 'error' ? 'bg-red-500/10 text-red-500 border-red-500/20' :
                            'bg-bg-input hover:bg-bg-elevated text-text-primary'
                        }`}
                    title={testError || "Test Connection"}
                >
                    {testStatus === 'testing' ? <><Loader2 size={12} className="animate-spin" /> Testing...</> :
                        testStatus === 'success' ? <><CheckCircle size={12} /> Connected</> :
                            testStatus === 'error' ? <><AlertCircle size={12} /> Error</> :
                                <>{/* No Icon */} Test Connection</>}
                </button>

                {/* Inline Model Dropdown */}
                {fetchedModels.length > 0 || preferredModel ? (
                    <ModelDropdown
                        dropdownRef={dropdownRef}
                        fetchedModels={fetchedModels}
                        selectedModel={selectedModel}
                        selectedOption={selectedOption}
                        preferredModel={preferredModel}
                        isOpen={isDropdownOpen}
                        isLight={isLight}
                        onToggle={toggleDropdown}
                        onSelect={handleSelectModel}
                    />
                ) : (
                    <div className="flex-1 mx-4" />
                )}

                {hasStoredKey ? (
                    <button
                        onClick={handleFetchModels}
                        disabled={isFetching}
                        className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors border border-border-subtle flex items-center gap-2 shrink-0 ${isFetching
                            ? 'bg-bg-input text-text-secondary'
                            : 'bg-accent-primary/10 text-accent-primary border-accent-primary/20 hover:bg-accent-primary/20'
                            }`}
                    >
                        {isFetching ? (
                            <><Loader2 size={12} className="animate-spin" /> Fetching...</>
                        ) : (
                            <><RefreshCw size={12} /> Fetch Models</>
                        )}
                    </button>
                ) : (
                    // Placeholder span to perfectly balance flex-between if button isn't shown
                    <span className="w-[110px]" />
                )}
            </div>

            {/* Error from test or fetch */}
            {testError && <p className="text-[10px] text-red-400 mt-1.5 mb-2">{testError}</p>}
            {fetchError && <p className="text-[10px] text-red-400 mt-1.5 mb-2">Model fetch error: {fetchError}</p>}
        </div>
    );
};